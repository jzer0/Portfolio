/*
Implementation of the Input class

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com/dx11tut13.html 

Modified for use in JobHuntGame by Justin Hansen
*/


#include <dinput.h>
#include"Input.h"
#include <string>
#include <sstream>
using namespace std;

// initialize class

Input::Input()
{
	directInput_= 0;
	keyboardDevice_ = 0;
	mouseDevice_ = 0;
	clicked=0;
	cbcount=20;
	cblink=FALSE;
	vpMatrix_=0;
	escaped=FALSE;
	rotation=0;
	mode=0;
	hsentry=FALSE;
	nameptr=NULL;
	memset(hsname,NULL,31);
	charnum=0;

}

Input::Input(const Input& other)
{

}

Input::~Input()
{

}

//initialize input object

bool Input::InputInitialize(HINSTANCE hinstance, HWND hwnd, int screenWidth, int screenHeight, ID3D11Device* d3dDevice_)
{

	HRESULT result;
	nameptr = &hsname[0];

	// target and cursor images

	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"target.png", 0, 0, &colorMap_[0], 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"cursor.png", 0, 0, &colorMap_[1], 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	XMFLOAT2 sprite1scale(.08f, .08f );
	XMFLOAT2 sprite1Pos( 1.0f, 1.0f );
	ginput[0].SetPosition( sprite1Pos );
	ginput[0].SetScale(sprite1scale);

	XMFLOAT2 sprite2scale(.048f, .048f );
	XMFLOAT2 sprite2Pos( 8000.0f, 7400.0f );
	ginput[1].SetPosition( sprite2Pos );
	ginput[1].SetScale(sprite2scale);


	// Store the screen size which will be used for positioning the mouse cursor.
	m_screenWidth = screenWidth;
	m_screenHeight = screenHeight;

	// Initialize the location of the mouse on the screen.
	mousePosX_ = 0;
	mousePosY_ = 0;

	// initialze input objects

	ZeroMemory( keyboardKeys_, sizeof( keyboardKeys_ ) );
	ZeroMemory( prevKeyboardKeys_, sizeof( prevKeyboardKeys_ ) );

	result = DirectInput8Create( hinstance, DIRECTINPUT_VERSION, IID_IDirectInput8, ( void** )&directInput_, 0 );

	if( FAILED( result ) )
	{ 
		return false;
	}
	mousePosX_ = mousePosY_ = mouseWheel_ = 500;

	result = directInput_->CreateDevice( GUID_SysMouse, &mouseDevice_, 0 );

	if( FAILED( result ) )
	{ 
		return false;
	}

	result = mouseDevice_->SetDataFormat( &c_dfDIMouse );

	if( FAILED( result ) )
	{ 
		return false;
	}

	result = mouseDevice_->SetCooperativeLevel( hwnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE );

	if( FAILED( result ) )
	{ 
		return false;
	}

	result = mouseDevice_->Acquire( );

	if( FAILED( result ) )
	{ 
		result = mouseDevice_->Acquire();
		while( FAILED( result ) ) 
			result = mouseDevice_->Acquire();
	}

	result = directInput_->CreateDevice( GUID_SysKeyboard, &keyboardDevice_, 0 );

	if( FAILED( result ) )
	{ 
		return false;
	}

	result = keyboardDevice_->SetDataFormat( &c_dfDIKeyboard );

	if( FAILED( result ) )
	{ 
		return false;
	}

	result = keyboardDevice_->SetCooperativeLevel( hwnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE );
	if( FAILED( result ) )
	{ 
		return false;
	}
	result = keyboardDevice_->Acquire( );

	if( FAILED( result ) )
	{ 
		// Error
		result = keyboardDevice_->Acquire();
		while( FAILED( result ) ) 
			result = keyboardDevice_->Acquire();

		// hr may be DIERR_OTHERAPPHASPRIO or other errors.  This
		// may occur when the app is minimized or in the process of 
		// switching, so just try again later 
		//	return !FAILED(hr); 
	}

	return true;
}

//cleanup

void Input::Shutdown()
{
	for (int i=0; i < 2; ++i)
	{
		if( colorMap_[i] ) colorMap_[i]->Release( );
		colorMap_[i] = 0;
	}
	// Release the mouse.
	if(mouseDevice_)
	{
		mouseDevice_->Unacquire();
		mouseDevice_->Release();
		mouseDevice_ = 0;
	}

	// Release the keyboard.
	if(keyboardDevice_)
	{
		keyboardDevice_->Unacquire();
		keyboardDevice_->Release();
		keyboardDevice_ = 0;
	}

	// Release the main interface to direct input.
	if(directInput_)
	{
		directInput_->Release();
		directInput_ = 0;
	}
	if( mvpCB_ ) mvpCB_->Release( );
	vpMatrix_=0;
}


bool Input::ReadKeyboard()
{
	HRESULT result;

	// Read the keyboard device.
	result = keyboardDevice_->GetDeviceState(sizeof(m_keyboardState), (LPVOID)&m_keyboardState);
	if(FAILED(result))
	{
		// If the keyboard lost focus or was not acquired then try to get control back.
		if((result == DIERR_INPUTLOST) || (result == DIERR_NOTACQUIRED))
		{
			keyboardDevice_->Acquire();
		}
		else
		{
			return false;
		}
	}
	return true;
}
bool Input::ReadMouse()
{
	HRESULT result;
	// Read the mouse device.
	result =  mouseDevice_->GetDeviceState(sizeof(DIMOUSESTATE), (LPVOID)&mouseState_);
	if(FAILED(result))
	{
		// If the mouse lost focus or was not acquired then try to get control back.
		if((result == DIERR_INPUTLOST) || (result == DIERR_NOTACQUIRED))
		{
			mouseDevice_->Acquire();
		}
		else
		{
			return false;
		}
	}

	return true;
}

void Input::GetMouseLocation(int& targetx, int& targety)
{
	targetx = mousePosX_;
	targety = mousePosY_;

	//adjust for target draw

	if( targetx>480)
	{
		targetx = 9800.0;
		mousePosX_ = 480;
		if( targety > 357)
		{
			targety = 7300.0;
			mousePosY_ = 357.0;
		}
		else  if ( targety  < 0.0)
		{
			targety= 1.0;
			mousePosY_ = 1.0;
		}
		else
		{
			targety = targety*20.5; 
		}
	}
	else if( targetx  < 0.0)
	{
		targetx = 1.0;
		mousePosX_= 1.0;
		if( targety > 357)
		{
			targety = 7300.0;
			mousePosY_ = 357.0;
		}
		else  if ( targety  < 0.0)
		{
			targety= 1.0;
			mousePosY_ = 1.0;
		}
		else
		{
			targety = targety*20.5;
		}
	}
	else if( targety > 357)
	{
		targety = 7300.0;
		mousePosY_ = 357.0;
		if( targetx>480)
		{
			targetx = 9800.0;
			mousePosX_ = 480;
		}
		else  if (targetx < 0.0)
		{
			targetx= 1.0;
			mousePosX_= 1.0;
		}
		else
		{
			targetx = targetx*20.5;
		}
	}   
	else if ( targety  < 0.0)
	{
		targety = 1.0;
		mousePosY_ = 1.0;
		if( targetx>480)
		{
			targetx = 9800.0;
			mousePosX_ = 480;
		}
		else if ( targetx  < 0.0)
		{
			targetx = 1.0;
			mousePosX_= 1.0;
		}
		else
		{
			targetx = targetx*20.5;
		}
	}
	else
	{
		targetx = targetx*20.5;
		targety = targety*20.5;
	}
	setTarget(targetx, targety);
}

void Input::Update(float dt)
{
	
	
	//check for user unput
	clicked=0;

	keyboardDevice_->GetDeviceState( sizeof( keyboardKeys_ ), ( LPVOID )&keyboardKeys_ );

	HRESULT result =  mouseDevice_->GetDeviceState( sizeof ( mouseState_ ), ( LPVOID ) &mouseState_ );
	if(FAILED(result))
	{
		// If the mouse lost focus or was not acquired then try to get control back.
		if((result == DIERR_INPUTLOST) || (result == DIERR_NOTACQUIRED))
		{
			mouseDevice_->Acquire();
		}

	}

	// keyboard entry detection for high score name

	if(mode==6&&hsentry)
	{
		float x, y;

		XMFLOAT2 newPos;
		y = ginput[1].getPosition().y;
		newPos.y=y;
		if(charnum < 32)
		{
			if(  KEYDOWN( prevKeyboardKeys_, DIK_BACK) && !KEYDOWN( keyboardKeys_, DIK_BACK ) )
			{  

				if(charnum==0)
				{
					x=ginput[1].getPosition().x;
				}
				else if(charnum >0)
				{

					--charnum;
					hsname[charnum] = NULL;
					if(charnum < 2)
					{
						x=ginput[1].getPosition().x-((31-charnum)*17.5);

					}
					else 
					{
						x=ginput[1].getPosition().x-225;
					}

				}

				newPos.x = x;
				ginput[1].SetPosition(newPos);

			}
		}
		if(charnum<=29)
		{
			if(  KEYDOWN( prevKeyboardKeys_, DIK_SPACE ) && !KEYDOWN( keyboardKeys_, DIK_SPACE ) )
			{ 
				hsname[charnum] = ' ';
			}

			for (int i=2; i<=11;++i)
			{
				if(  KEYDOWN( prevKeyboardKeys_, i ) && !KEYDOWN( keyboardKeys_, i ) )
				{ 
					switch(i)
					{
					case 2:
						hsname[charnum] = '1';
						break;
					case 3:
						hsname[charnum] = '2';
						break;
					case 4:
						hsname[charnum] = '3';
						break;
					case 5:
						hsname[charnum] = '4';
						break;
					case 6:
						hsname[charnum] = '5';
						break;
					case 7:
						hsname[charnum] = '6';
						break;
					case 8:
						hsname[charnum] = '7';
						break;
					case 9:
						hsname[charnum] = '8';
						break;
					case 10:
						hsname[charnum] = '9';
						break;
					case 11:
						hsname[charnum] = '0';
						break;

					default:
						hsname[charnum] = NULL;
						break;
					}
				}
			}

			for (int j=16; j<=50;++j)
			{
				if(  KEYDOWN( prevKeyboardKeys_, j ) && !KEYDOWN( keyboardKeys_, j ) )
				{ 
					switch(j)
					{
					case 16:
						hsname[charnum] = 'Q';
						break;
					case 17:
						hsname[charnum] = 'W';
						break;
					case 18:
						hsname[charnum] = 'E';
						break;
					case 19:
						hsname[charnum] = 'R';
						break;
					case 20:
						hsname[charnum] = 'T';
						break;
					case 21:
						hsname[charnum] = 'Y';
						break;
					case 22:
						hsname[charnum] = 'U';
						break;
					case 23:
						hsname[charnum] = 'I';
						break;
					case 24:
						hsname[charnum] = 'O';
						break;
					case 25:
						hsname[charnum] = 'P';
						break;
					case 30:
						hsname[charnum] = 'A';
						break;
					case 31:
						hsname[charnum] = 'S';
						break;
					case 32:
						hsname[charnum] = 'D';
						break;
					case 33:
						hsname[charnum] = 'F';
						break;
					case 34:
						hsname[charnum] = 'G';
						break;
					case 35:
						hsname[charnum] = 'H';
						break;
					case 36:
						hsname[charnum] = 'J';
						break;
					case 37:
						hsname[charnum] = 'K';
						break;
					case 38:
						hsname[charnum] = 'L';
						break;
					case 44:
						hsname[charnum] = 'Z';
						break;
					case 45:
						hsname[charnum] = 'X';
						break;
					case 46:
						hsname[charnum] = 'C';
						break;
					case 47:
						hsname[charnum] = 'V';
						break;
					case 48:
						hsname[charnum] = 'B';
						break;
					case 49:
						hsname[charnum] = 'N';
						break;
					case 50:
						hsname[charnum] = 'M';
						break;

					default:
						hsname[charnum] = NULL;
						break;
					}
				}
			}
		
		
		if(hsname[charnum]!=NULL&&charnum<=29)
		{
			if(charnum < 2)
			{
				x=ginput[1].getPosition().x+((31-charnum)*17.5);

			}
			else
			{
				x=ginput[1].getPosition().x+225;

			}
			newPos.x=x;
			ginput[1].SetPosition(newPos);
			++charnum;
		}
	}
}

// mouse input detection

if( BUTTONDOWN( mouseState_, 0 ) && !BUTTONDOWN( prevMouseState_, 0 ) ) 
{

	clicked=1;
}
else
{
	clicked=0;
}
if( BUTTONDOWN( mouseState_, 1 ) && !BUTTONDOWN( prevMouseState_, 1 ) )
{ 
	clicked=1;
} 
mousePosX_ += mouseState_.lX;
mousePosY_ -= mouseState_.lY;
mouseWheel_ += mouseState_.lZ;

memcpy( prevKeyboardKeys_, keyboardKeys_, sizeof( keyboardKeys_ ) );
memcpy( &prevMouseState_, &mouseState_, sizeof( mouseState_ ) );

if( clicked < 0 ) clicked = 2;
if( clicked > 2 ) clicked = 0;
}

// render input objects

void Input::Render()
{
	// draw target and cursor if necessary

	int targetx, targety;
	GetMouseLocation(targetx,targety);

	rotation = rotation+.1;
	if(rotation==6.3)
	{
		rotation=0;
	}
	ginput[0].SetRotation(rotation);
	XMFLOAT2 targetPostition ((float)targetx,(float)targety);
	XMMATRIX vpMatrix;
	vpMatrix.operator=(*(vpMatrix_));
	XMMATRIX world= ginput[0].GetWorldMatrix( );
	XMMATRIX mvp = XMMatrixMultiply( world, vpMatrix );
	ginput[0].SetPosition(targetPostition);
	mvp = XMMatrixTranspose( mvp );
	d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
	d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
	d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[0]);
	d3dContext_->Draw( 6, 0 );

	// draw, blink cursor

	if(mode==6&&hsentry)
	{
		if(!cblink&&cbcount>0)
		{
			world=ginput[1].GetWorldMatrix( );
			mvp = XMMatrixMultiply( world, vpMatrix );
			mvp = XMMatrixTranspose( mvp );
			d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
			d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
			d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[1]);

			d3dContext_->Draw( 6, 0 );
			--cbcount;
		}
		else if(cbcount==0)
		{
			cblink=!cblink;
			cbcount = 20;
		}
		else
		{
			--cbcount;
		}
	}
}

// lets scene know about mouse click

int Input::getSelectedColor()
{
	return clicked;
}

bool Input::Frame()
{
	// Maintain focus for input 

	bool result;

	// Read the current state of the keyboard.
	result = ReadKeyboard();
	if(!result)
	{
		return false;
	}

	// Read the current state of the mouse.
	result = ReadMouse();
	if(!result)
	{
		return false;
	}
	return result;

}

// sets required variables to get input to interact with scene

void Input::setContext(ID3D11DeviceContext* dContext_, ID3D11Buffer* PmvpCB_, XMMATRIX* pvpMatrix_, int m, bool sentry)
{
	d3dContext_ = dContext_;
	mvpCB_ = PmvpCB_;
	vpMatrix_ = pvpMatrix_;
	mode=m;
	hsentry=sentry;
}

// returns x, y position of the mouse cursor, used for detecting if a duck has been shot

int Input::getX()
{
	return scopeX;
}

int Input::getY()
{
	return scopeY;
}
void Input::setTarget(int x, int y)
{
	scopeX = x;
	scopeY = y;
}

// check if escape has been pressed

bool Input::escapepress()
{
	escaped=FALSE;
	if( KEYDOWN( keyboardKeys_, DIK_ESCAPE ) )
		if( GetAsyncKeyState( VK_ESCAPE ) )
		{ 
			//PostQuitMessage( 0 );
			escaped=TRUE;

		}


		return escaped;
}

// get high score name to be saveed by stats class

char* Input::getname()
{
	return nameptr;
}

//clear the entered  high score name

void Input::clearName()
{
	memset(hsname,NULL,31);
	nameptr = &hsname[0];
	charnum=0;
	XMFLOAT2 sprite2Pos( 8000.0f, 7400.0f );
	ginput[1].SetPosition( sprite2Pos );
}