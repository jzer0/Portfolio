/*
Header file for TextClass

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/
#ifndef _TEXT_CLASS_
#define _TEXT_CLASS_

#include"Dx11Base.h"
#include "Sprites.h"

class TextClass : public Dx11Base
{

public:

	TextClass( );
	virtual ~TextClass( );
	void setContext(ID3D11DeviceContext* dContext_, float xcord, float ycord, char* msg, int font, float cw, float ch, float tw);
	void Update( float dt );
	void UnloadContent( );
	void Render();

	bool LoadContent(ID3D11Device* d3dDevice_);

private:

	bool DrawString(char* message, float startX, float startY);


private:
	
	ID3D11ShaderResourceView* colorMap_[2];
	ID3D11SamplerState* colorMapSampler_;
	ID3D11VertexShader* solidColorVS_;
	ID3D11PixelShader* solidColorPS_;
	ID3D11InputLayout* inputLayout_;
	ID3D11Buffer* vertexBuffer_;  
	XMFLOAT2 fontscale;

	char* textmessage;
	
	float mlocationX;
	float mlocationY;
	float charWidth;
	float charHeight;
	float texelWidth;

	int fontype;
};

#endif