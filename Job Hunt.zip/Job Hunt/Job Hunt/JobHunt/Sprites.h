/*
Header file for the Sprites Class

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/

#ifndef _SPRITES_H_
#define _SPRITES_H_

#include<xnamath.h>


class Sprites
{

public:

	Sprites( );
	virtual ~Sprites( );

	XMMATRIX GetWorldMatrix( );
	XMFLOAT2 getPosition();

	void SetPosition( XMFLOAT2& position );
	void SetRotation( float rotation );
	void SetScale( XMFLOAT2& scale );

private:

	XMFLOAT2 position_;
	XMFLOAT2 scale_;
	float rotation_;
};

#endif