/*
Header file for the JobHuntGame Class

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/

#ifndef _JOB_HUNT_GAME_H_
#define _JOB_HUNT_GAME_H_

#include"Dx11Base.h"
#include"Sprites.h"
#include"Input.h"
#include "TextClass.h"
#include "Scene.h"
#include "MenuClass.h"
#include "StatsClass.h"
#include "SoundClass.h"

class JobHuntGame : public Dx11Base
{
public:

	JobHuntGame();
	virtual ~JobHuntGame( );
	bool LoadGame(HINSTANCE hInstance, HWND hwnd, int screenWidth, int screenHeight,ID3D11Device* Pd3dDevice_, ID3D11DeviceContext* Pd3dContext_ );
	void Update( float dt);
	void initcolor(int x);
	void UnloadGame( );
	void Render( );
	void reset();	
	void showSmess();

private:

	SoundClass* m_Sound;
	StatsClass* stats;
	TextClass* texter;
	MenuClass* menu;
	Scene* nature;
	Input* user_;
	char* score;

	bool Cplayed;
	bool tmode;
	bool miscount;
	bool scoreDisp;
	bool quit;
	bool alreadyset;
	bool fallplayed;
	bool statplay;
	bool sshown;
	bool ckills;
	bool scoredone;
	bool focused;
	bool started;
	bool cround;
	bool released;
	bool iplayed;

	int lmmode;
	int font;
	int hits;
	int ds;
	int ls;
	int mmode;
	int clicked;
	int delay;
	int scoreX;
	int scoreY;
	int scoreX2;
	int scoreY2;
	int menuwait;
	int mode;
	int curx;
	int cury;
	int sdelay;
	int wingdelay;
	int played;
	int cmode;
	int smode;
	int kills;
	int escapes;
};

#endif