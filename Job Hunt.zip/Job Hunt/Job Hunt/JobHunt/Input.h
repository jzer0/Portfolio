/*
Header file for the Input class

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com/dx11tut13.html

Modified for use in JobHuntGame by Justin Hansen
*/

#ifndef _INPUT_H_
#define _INPUT_H_

#include <dinput.h>
#include"Dx11Base.h"
#include "Sprites.h"

#define KEYDOWN(name, key) ( name[key] & 0x80 )
#define BUTTONDOWN(device, key) ( device.rgbButtons[key] & 0x80 )

class Input : public Dx11Base
{

public:

	Input();
	Input(const Input&);
	~Input();
	void setContext(ID3D11DeviceContext* dContext_, ID3D11Buffer* PmvpCB_, XMMATRIX* pvpMatrix_, int m, bool sentry);
	void setMouseLocation(int targetx, int targety);
	void GetMouseLocation(int&, int&);
	void setTarget(int x, int y);
	void Update( float dt);
	void clearName();
	void Shutdown();
	void Render( );	

	char* getname();
	
	bool InputInitialize(HINSTANCE hInstance, HWND hwnd, int screenWidth, int screenHeight,ID3D11Device* d3dDevice_);
	bool IsEscapePressed();
	bool escapepress();
	bool Frame();

	int getSelectedColor();
	int getX();
	int getY();



protected:

	ID3D11ShaderResourceView* colorMap_[2];
	LPDIRECTINPUTDEVICE8 keyboardDevice_;
	LPDIRECTINPUTDEVICE8 mouseDevice_;
	DIMOUSESTATE prevMouseState_;
	LPDIRECTINPUT8 directInput_;
	DIMOUSESTATE mouseState_;
	ID3D11Buffer* mvpCB_;
	XMMATRIX* vpMatrix_;
	Sprites ginput[2];

	void ProcessInput();
	bool ReadKeyboard();
	bool ReadMouse();

	bool escaped;
	bool hsentry;
	bool cblink;

	unsigned char m_keyboardState[256];
	char prevKeyboardKeys_[256];
	char keyboardKeys_[256];
	char hsname[33];
	char* nameptr;

	long mouseWheel_;
	float rotation;
		
	int m_screenWidth, m_screenHeight;
	int mousePosX_;
	int mousePosY_;
	int clicked;
	int scopeX;
	int scopeY;
	int cbcount;
	int charnum;
	int mode;

};

#endif