/*
Implementation file for StatsClass

Example references:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/


#include"StatsClass.h"
#include<xnamath.h>
#include <iostream>
#include <string>
#include <sstream>
#include <ctype.h>
using namespace std;

struct VertexPos
{
	XMFLOAT3 pos;
	XMFLOAT2 tex0;

};

// initialize vaiables

StatsClass::StatsClass( ) 
{
	wait=0;
	mode=0;
	ptrvpMatrix_ = 0;
	font=0;
	ammo = 3;
	bdelay=10;
	roundmsg = "ROUND ";
	msg = NULL;
	msgx= 0;
	msgy=0;
	nround = TRUE;
	gover=FALSE;
	round=1;
	dcount=0;
	score=0;
	rkills=0;
	tally=FALSE;
	flasher=3;
	newduck = TRUE;
	upscore=FALSE;
	lcount=0;
	isinplay=0;
	hsnameptr=NULL;
	tdelay=0;
	tflash=0;
	wasplayed=0;
	flashtally=FALSE;
	highscore=FALSE;
	flymsg=FALSE;
	misses=0;
	playsound=0;
	dscores=FALSE;
	namepos=4300;
	mvpCB_=0;
	lcarcnt= 0;
	reportwin=FALSE;
	memset(sslot,NULL,39);
	memset(bslot,NULL,39);
	memset(newHScore,NULL,39);
	memset(beatscores,0,9);
	memset (scoremsg,NULL,9);
	scoremsg[0]='0';
	memset(rnum,NULL,5);
	rnum[0]='1';
	for (int i = 0; i < 9; ++i)
	{

		colorMap_[i] = 0;
	}
	for (int i = 0; i < 10; ++i)
	{

		roundkills[i][0] = -1;
	}
}

StatsClass::~StatsClass( )
{

}

// initialize statsclass object

bool StatsClass::LoadStats(ID3D11Device* d3dDevice_, TextClass* texter)
{

	HRESULT result;
	highscore=FALSE;

	// point to textclass object of jobhuntgame

	statstext = texter;

	// load statsclass images for sprites

	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"clip.png", 0, 0, &colorMap_[0], 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"ammo.png", 0, 0, &colorMap_[1], 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"hithud.png", 0, 0, &colorMap_[2], 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"blankduck.png", 0, 0, &colorMap_[3], 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"currentduck.png", 0, 0, &colorMap_[4], 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"missedduck.png", 0, 0, &colorMap_[5], 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"caughtduck.png", 0, 0, &colorMap_[6], 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"scoreboard.png", 0, 0, &colorMap_[7], 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"popup.png", 0, 0, &colorMap_[8], 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"rounder.png", 0, 0, &colorMap_[9], 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	// initialize sprite scale and initial locations

	XMFLOAT2 sprite1Pos( 400.5f, 300.0f );
	XMFLOAT2 sprite1scale( .105f, .08f );
	info[0].SetScale(sprite1scale);
	info[0].SetPosition( sprite1Pos );

	XMFLOAT2 sprite2scale( .016f, .03f );
	XMFLOAT2 sprite2Pos( 1500.5, 1080.0f );
	info[1].SetPosition( sprite2Pos);
	info[1].SetScale(sprite2scale);

	XMFLOAT2 sprite3Pos( 2600.5, 1080.0f );
	info[2].SetPosition( sprite3Pos);
	info[2].SetScale(sprite2scale);

	XMFLOAT2 sprite4Pos( 3700.5, 1080.0f );
	info[3].SetPosition( sprite4Pos);
	info[3].SetScale(sprite2scale);

	XMFLOAT2 sprite5scale( .45f, .08f );
	XMFLOAT2 sprite5Pos( 885.5f, 300.0f );
	info[4].SetPosition( sprite5Pos );
	info[4].SetScale(sprite5scale);

	XMFLOAT2 sprite6scale( .035f, .035f );
	XMFLOAT2 sprite6Pos( 9700.5f, 900.0f );
	info[5].SetPosition( sprite6Pos );
	info[5].SetScale(sprite6scale);

	XMFLOAT2 sprite7Pos( 10300.5f, 900.0f );
	info[6].SetPosition( sprite7Pos );
	info[6].SetScale(sprite6scale);

	XMFLOAT2 sprite8Pos( 10900.5f, 900.0f );
	info[7].SetPosition( sprite8Pos );
	info[7].SetScale(sprite6scale);

	XMFLOAT2 sprite9Pos( 11500.5f, 900.0f );
	info[8].SetPosition( sprite9Pos );
	info[8].SetScale(sprite6scale);

	XMFLOAT2 sprite10Pos( 12100.5f, 900.0f );
	info[9].SetPosition( sprite10Pos );
	info[9].SetScale(sprite6scale);

	XMFLOAT2 sprite11Pos( 12700.5f, 900.0f );
	info[10].SetPosition( sprite11Pos );
	info[10].SetScale(sprite6scale);

	XMFLOAT2 sprite12Pos( 13300.5f, 900.0f );
	info[11].SetPosition( sprite12Pos );
	info[11].SetScale(sprite6scale);

	XMFLOAT2 sprite13Pos( 13900.5f, 900.0f );
	info[12].SetPosition( sprite13Pos );
	info[12].SetScale(sprite6scale);

	XMFLOAT2 sprite14Pos( 14500.5f, 900.0f );
	info[13].SetPosition( sprite14Pos );
	info[13].SetScale(sprite6scale);

	XMFLOAT2 sprite15Pos( 15100.5f, 900.0f );
	info[14].SetPosition( sprite15Pos );
	info[14].SetScale(sprite6scale);

	XMFLOAT2 sprite16scale( .24f, .081f );
	XMFLOAT2 sprite16Pos( 2980.5f, 290.0f );
	info[15].SetPosition( sprite16Pos );
	info[15].SetScale(sprite16scale);

	XMFLOAT2 sprite17scale( .28f, .2f );
	XMFLOAT2 sprite17Pos( 1400.0f, 1600.0f );
	info[16].SetPosition( sprite17Pos );
	info[16].SetScale(sprite17scale);

	XMFLOAT2 sprite18Pos( 1120.5f, 520.0f );
	XMFLOAT2 sprite18scale( .1f, .057f );
	info[18].SetScale(sprite18scale);
	info[18].SetPosition( sprite18Pos );

	// read in high score file

	std::ostringstream scorechar;
	string hscore;

	ifstream myfile ("highscores.txt");
	char pch[5];
	if (myfile.is_open())
	{
		int i = 0;

		while ( myfile.good() )
		{

			// extract high score of each line

			getline(myfile,hscore);
			memset(sslot,NULL,38);
			scorptr = hscores[i];
			strncpy(sslot,  scorptr,38);
			strncpy(scorptr, hscore.c_str(), hscore.size());
			strncpy(pch, hscore.c_str(), 5); 
			hs = atoi(pch);	
			beatscores[i] = hs;
			++i;
		}
		myfile.close();
	}
	else 
	{
		return false;
	} 
	return true;

}

// set variables needed to render statsclass objects

void StatsClass::setContext( ID3D11DeviceContext* pd3dContext_,ID3D11Buffer* pmvpCB_,XMMATRIX* PvpMatrix_, bool inflight, int inplay,int gtype, int tleft, char* hsname)
{
	d3dContext_ = pd3dContext_;
	mvpCB_ = pmvpCB_;
	ptrvpMatrix_ = PvpMatrix_;
	gametype = gtype;

	hsnameptr=hsname;
	isinplay = inplay;
	isinflight=inflight;
	ctargets = tleft;

}

// update not used, other functions implemented

void StatsClass::Update( float dt)
{

}
// tell Jobhuntgame if scores are being displayed

bool StatsClass::displayedscores()
{
	return dscores;
}

// turn of display scores

void StatsClass::resetdisp()
{
	dscores=FALSE;
}

// let statsclass know that high score name has been saved

void StatsClass::seths(bool set)
{
	highscore= set;
	score=0;
}

// let jhg know that statsclass is ready for a new round

bool StatsClass::getround()
{
	return nround;
}

// tell jhg to play a stats sound

int StatsClass::soundplay()
{
	return playsound;
}

// render statsclass objects

void StatsClass::Render()
{

	unsigned int stride = sizeof( VertexPos );
	unsigned int offset = 0;
	XMMATRIX vpMatrix_;
	vpMatrix_.operator=(*(ptrvpMatrix_));
	XMMATRIX world;

	// check to see if in high score mode

	if(mode!=6)
	{

		// render statsclass sprites

		d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[0] );
		world = info[0].GetWorldMatrix( );
		XMMATRIX mvp = XMMatrixMultiply( world, vpMatrix_ );
		mvp = XMMatrixTranspose( mvp );

		d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
		d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
		d3dContext_->Draw( 6, 0 );

		d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[1] );
		if (ammo >0)
		{
			for (int i = ammo; i > 0; --i)
			{
				world = info[i].GetWorldMatrix( );
				vpMatrix_.operator=(*(ptrvpMatrix_));
				mvp = XMMatrixMultiply( world, vpMatrix_ );
				mvp = XMMatrixTranspose( mvp );
				d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
				d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
				d3dContext_->Draw( 6, 0 );
			}
		}

		d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[9] );
		world = info[18].GetWorldMatrix( );
		vpMatrix_.operator=(*(ptrvpMatrix_));

		mvp = XMMatrixMultiply( world, vpMatrix_ );
		mvp = XMMatrixTranspose( mvp );

		d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
		d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
		d3dContext_->Draw( 6, 0 );

		d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[2] );
		world = info[4].GetWorldMatrix( );
		vpMatrix_.operator=(*(ptrvpMatrix_));

		mvp = XMMatrixMultiply( world, vpMatrix_ );
		mvp = XMMatrixTranspose( mvp );

		d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
		d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
		d3dContext_->Draw( 6, 0 );

		// check if score tally needs to be run

		if(tally)
		{
			runtally();
			mode=1;
		}

		// check if tally is done and need to flash the successful hits

		if(tflash>0)
		{  
			if(tflash==10)
			{
				if(rkills>=5&&wait==0)
				{
					if(rkills>=7)
					{
						string r;
						switch(rkills)
						{
							// popups for decent scores
						case 9:
							{
								r= "GREAT";
								msgx=3800;
								break;
							}
						case 10:
							{
								r = "PERFECT";
								msgx=3585;
								font=1;
								break;
							}
						default:
							{ r= "GOOD";
							msgx=3900;
							break;
							}
						}
						reportwin=TRUE;
						 msg = new char[r.size()+1];
						strcpy(msg, r.c_str());
						wait=110;
					}
					playsound=10;
				}
				else if(rkills<5&&wait==0)
				{
					// game over 
					if(!gover)
					{
						gover=TRUE;
						wait=110;
						string r = "GAME OVER";
						msg = new char[r.size()+1];
						strcpy(msg, r.c_str());
						msgx=3350;
						playsound=11;

					}
					else if(highscore&&gover)
					{
						// go into high score mode if game over and high score
						mode=6;
					}
				}

			}
			else
			{
				playsound=0;
			}
			mode=2;
			if(tdelay==0)
			{
				--tflash;
				if(tflash!=0)
				{
					flashtally = !flashtally;
					tdelay=28;
				}
				else
				{
					for (int z = 0; z < 10; ++z)
					{

						roundkills[z][0] = -1;
					}
					flashtally=FALSE;



				}
			}
			else
			{--tdelay;}
		}

		int k = 0;
		// display the hit tracking panel indicating successful hits, misses, and flashing of current target indication
		for (int j = 5; j <= 15; ++j)
		{
			if(j-5-dcount==0&&isinflight&&isinplay<1)
			{
				if(bdelay==0)
				{
					if(flasher==3)
					{
						++flasher;
					}
					else
					{
						--flasher;
					}
					d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[flasher] );
					if(gametype>=3)
					{
						if(ctargets<2&&isinplay<1)
						{
							world = info[j].GetWorldMatrix( );
							vpMatrix_.operator=(*(ptrvpMatrix_));
							mvp = XMMatrixMultiply( world, vpMatrix_ );
							mvp = XMMatrixTranspose( mvp );
							d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
							d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
							d3dContext_->Draw( 6, 0 );
							++j;
						}
					}
					bdelay=10;
				}
				else
				{
					d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[flasher]);
					if(gametype>=3)
					{
						if(ctargets==0)
						{
							world = info[j].GetWorldMatrix( );
							vpMatrix_.operator=(*(ptrvpMatrix_));
							mvp = XMMatrixMultiply( world, vpMatrix_ );
							mvp = XMMatrixTranspose( mvp );
							d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
							d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
							d3dContext_->Draw( 6, 0 );
							++j;
						}
					}
					--bdelay;
				}
			}
			else if(roundkills[k][0] == 1)
			{
				if(!flashtally)
				{
					d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[6] );
				}
				else
				{
					d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[3] );
				}
			}
			else if(roundkills[k][0] == 0)
			{
				d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[5] );
			}
			else
			{ 
				d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[3] );
			}
			++k;
			world = info[j].GetWorldMatrix( );
			vpMatrix_.operator=(*(ptrvpMatrix_));
			mvp = XMMatrixMultiply( world, vpMatrix_ );
			mvp = XMMatrixTranspose( mvp );
			d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
			d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
			d3dContext_->Draw( 6, 0 );
		}

		d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[7] );
		world = info[15].GetWorldMatrix( );
		vpMatrix_.operator=(*(ptrvpMatrix_));
		mvp = XMMatrixMultiply( world, vpMatrix_ );
		mvp = XMMatrixTranspose( mvp );
		d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
		d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
		d3dContext_->Draw( 6, 0 );

		// determine whether any messages need to be displayed

		if((isinplay==0)||(isinplay>0&&wait>0)&&!reportwin)
		{
			wasplayed=isinplay;

		}
		else if(isinplay>wasplayed&&wait==0&&msg==NULL&&!reportwin&&!nround)
		{
			// flyaway message

			flymsg=TRUE;
			wasplayed=isinplay;
			wait=92;
			font=0;
			string r = "FLY AWAY";
			msg = new char[r.size()+1];
			strcpy(msg, r.c_str());
			msgx=3500;

		}
		if (wait >0&&((reportwin)||(gover)||((!tally&&tflash==0)||((isinplay>=1)&&(msg!=NULL||nround)&&flymsg))))
		{
			// display message

			d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[8] );
			world = info[16].GetWorldMatrix( );
			vpMatrix_.operator=(*(ptrvpMatrix_));
			mvp = XMMatrixMultiply( world, vpMatrix_ );
			mvp = XMMatrixTranspose( mvp );

			d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
			d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
			d3dContext_->Draw( 6, 0 );
			if(isinplay==0&&!gover&&!reportwin)
			{
				statstext->setContext(d3dContext_, 3450, 3280, roundmsg, 0, 20.0, 29.5, 55.2);
				statstext->Render();
				if(round<10&&!flymsg)
				{
					msgx=4950;
				}
				else
				{
					msgx =4850;
				}
			}
			if(flymsg&&!nround)
			{
				msgx=3500;
			}
			if(tflash>0)
			{
				switch(rkills)
				{
				case 9:
					msgx=3800;
					break;

				case 10:
					msgx=3585;
					font=1;
					break;

				default:

					msgx=3900;
					break;
				}
			}
			if(gover)
			{
				msgx=3350;
			}
			
				statstext->setContext(d3dContext_,msgx, 3280, msg, font, 20.0, 29.5, 55.2);
			
			statstext->Render();
			--wait;
		}

		// finish up displaying messages

		else if (wait==0&&!tally&&tflash==0&&(nround||gover||reportwin||msg!=NULL))
		{ 
			if(nround)
			{
				if(tflash==0&&!tally)
				{
					nround= FALSE;
					
					std::ostringstream roundchar;
					roundchar<<round;
					string r = roundchar.str().c_str();
					msg = new char[r.size()+1];
					strcpy(rnum, r.c_str());
					strcpy(msg, r.c_str());
					wait=125;
					reportwin=FALSE;
		
				}
			}
			else if(reportwin)
			{
				delete []msg;
				msg = NULL;
				reportwin=FALSE;
				font=0;
			}
			else if(!nround&&msg!=NULL)
			{
				delete []msg;
				msg = NULL;
				flymsg=FALSE;
				mode=0;
			}
		}

		// increase the score displayed

		if(upscore)
		{
			std::ostringstream scorechar;
			scorechar<<score;
			string s = scorechar.str().c_str();
			strcpy(scoremsg, s.c_str());
			upscore=FALSE;
			highscore=FALSE;
			highscore=ishighscore(score);
		}

		// switch the score font if high score achieved

		if(highscore)
		{
			font=1;
		}else
		{
			font=0;
		}

		// render the current score text
		statstext->setContext(d3dContext_,10500,85, scoremsg,font,18.5,28.0,55.25);
		statstext->Render();
		font=0;
		if(round>=10)
		{
			msgx = 850;
		}
		else
		{
			msgx = 950;
		}
		
		statstext->setContext(d3dContext_,msgx, 80, rnum, 1, 14.0, 23.5, 55.2);
		statstext->Render();
	}

	// high score mode

	else if(mode==6)
	{
		highscore=FALSE;
		highscore=ishighscore(score);

		// input high score if achieved

		if(highscore)
		{
			playsound=12;
			statstext->setContext(d3dContext_, 2050, 5880, "NEW HIGH SCORE", 1, 30.0, 39.5, 55.2);
			statstext->Render();
			statstext->setContext(d3dContext_, 1500, 5080, "ENTER YOUR NAME", 1, 35.0, 44.5, 55.2);
			statstext->Render();
			if(hsnameptr!=NULL)
			{
				int carcnt = 0;
				while (hsnameptr[carcnt]!=NULL)
				{
					++carcnt;
				}
				if (carcnt<=31&&abs(lcarcnt-carcnt)>1)
				{
					carcnt=0;
					lcarcnt=0;
					namepos=4300;
				}
				if(carcnt >lcarcnt)
				{
					if(namepos<=4400&&namepos>120)
					{
						namepos=namepos-140;
						lcarcnt= carcnt;
					}
				}
				else if(carcnt <lcarcnt)
				{
					if(namepos<=4400||namepos>120)
					{
						namepos=namepos+140;
						lcarcnt= carcnt;
					}
				}
				statstext->setContext(d3dContext_, namepos, 3880, hsnameptr, 0, 25.0, 34.5, 55.2);
				statstext->Render();
				memset(scorename,NULL,32);
				strcpy(scorename,hsnameptr);
			}
		}
		else 
		{
			// display high scores

			statstext->setContext(d3dContext_, 2650, 5880, "HIGH SCORES", 1, 30.0, 39.5, 55.2);
			statstext->Render();
			msgy=5400;
			for(int i = 0; i<10;++i)
			{
				memset(sslot,NULL,38);
				scorptr = hscores[i];
				strncpy(sslot,  scorptr,38);
				statstext->setContext(d3dContext_, 530, msgy, sslot, 0, 20.0, 29.5, 55.2);
				statstext->Render();
				msgy = msgy - 400;
			}
			dscores=TRUE;
		}
	}
	ptrvpMatrix_=0;
}

// cleanup

void StatsClass::UnloadStats()
{

	for(int i = 0; i < 9; ++i)
	{
		if( colorMap_[i] ) colorMap_[i]->Release( );
		colorMap_[i] = 0;
	}
	if( mvpCB_ )mvpCB_->Release( );
	statstext=0;
	mvpCB_ = 0;
	ptrvpMatrix_=0;

}

// used to determine font 

int StatsClass::getFont(int tX, int tY)
{
	return font;
}

// used by jhg to check mode

int StatsClass::getMode()
{
	return mode;
}

// used by jhg to set the mode

void StatsClass::setMode(int m)
{
	mode=m;
}

// tells statsclass to increase score

void StatsClass::scored()
{
	roundkills[dcount][0]=1;
	++dcount;
	score = score+100;
	upscore=TRUE;
}

// increase round for statsclass variables

void StatsClass::nextround()
{
	++round;
	tally=TRUE;
	nround=TRUE;
	dcount=0;
	mode=1;
	ptrvpMatrix_ = 0;
}

// tell jhg that statsclass is ready for new round, not tallying or other ops

bool StatsClass::checkround()
{
	return nround;
}

// operation to tally the hit indicator, shifting the hits to the left and misses to the right

void StatsClass::runtally()
{
	bool shift = FALSE;
	int i = 0;
	int j = 9;
	playsound=0;
	if(tdelay==0)
	{
		while(i<10&&!shift&&j>0)
		{
			if(roundkills[i][0]==0)
			{
				while(j>0&&!shift)
				{
					if (roundkills[j][0]==0)
					{
						if(j-i>1)
						{
							--j;
						}
						else
						{j=0;}
					}
					else
					{
						if(j>0)
						{
							roundkills[j][0]=0;
							shift=TRUE;										
						}
					}
				}
			}
			if(!shift&&j>0)
			{
				++i;
			}
		}
		if (shift)
		{
			roundkills[i][0]=1;

			// play the shift sound

			playsound=9;
		}
		else if(j==0||i==10)
		{
			tally=FALSE;
			tflash=10;
			rkills=i;
		}
		tdelay=15;	
	}
	else
	{
		if(tdelay>0)
		{
			--tdelay;
		}
	}
}

// lets jhg know that there is ammo and shooting is possible in game mode

bool StatsClass::fired(int clicked)
{
	canshoot = FALSE;
	if(clicked==1&&isinplay<1)
	{
		if (ammo >0)
		{
			canshoot = TRUE;

			--ammo;

		}

	}
	return canshoot;
}

// reloads ammo

void StatsClass::reload()
{
	ammo=3;
}

// sets hit indicator to show a miss

void StatsClass::missed()
{
	roundkills[dcount][0]=0;
	++dcount;

}

// jhg check if in a tally mode

bool StatsClass::checkTally()
{
	return tally;
}

// lets jhg know that game is over and high score is saved

bool StatsClass::getgover()
{
	if(gover&&wait==0)
	{
		if(highscore)
		{
			mode=6;
			return FALSE;
		}
		else{

			return TRUE;
		}
	}
	else
	{
		return FALSE;
	}

}

// checks if the current score is a high score

bool StatsClass::ishighscore(int endscore)
{
	if(endscore >beatscores[9])
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

// lets jhg know that stats is running the high score entry mode

bool StatsClass::getHSmode()
{
	return highscore;
}

// function to save the high score to the high scores file

void StatsClass::saveName()
{
	string hscore;
	memset(sslot,NULL,39);
	memset(bslot,NULL,39);
	memset(newHScore,NULL,39);
	char pch[5];
	int i = 0;
	hs=0;

	// determine where to place the score

	while ( hs==0||hs>=score)
	{
		memset(sslot,NULL,38);
		scorptr = &hscores[i][0];
		strncpy(sslot,  scorptr,38);
		strncpy(pch, sslot, 5); 
		hs = atoi(pch);	
		beatscores[i] = hs;
		++i;
	}
	if(i >0)
	{
		--i;
	}
	std::ostringstream scorechar;
	scorechar<<score;
	string s = scorechar.str().c_str();
	strcpy(scoremsg, s.c_str());
	upscore=FALSE;
	char* spaces;
	if(score <10000)
	{
		spaces = "   ";
	}
	else if(score >99999)
	{
		spaces = " ";
	}
	else
	{
		spaces ="  ";	
	}
	strcpy(newHScore,scoremsg);
	strcat(newHScore,spaces);
	strcat(newHScore,scorename);
	int j = 38;
	while(newHScore[j]==NULL)
	{
		newHScore[j]='�';
		--j;
	}

	//save score in its place if needed

	if (i <9)
	{
		strncpy(sslot,  hscores[i], 38);
	}
	strncpy(hscores[i], newHScore,38);
	++i;

	// shift scores  down according to newest entry

	while ( i<10)
	{
		if(i+1 < 10)
		{
			strncpy(bslot,  hscores[i],38);
		}
		strncpy(hscores[i], sslot,39);
		memset(sslot,NULL,39);
		strncpy(sslot,  bslot,39);
		++i;
	}

	// remove the old high scores file and write a new one

	remove("highscores.txt");
	ofstream outfile("highscores.txt",ios::out);
	if (outfile.is_open())
	{
		int i = 0;
		while(i <10)
		{
			memset(sslot,NULL,38);
			scorptr = hscores[i];
			strncpy(sslot,  scorptr,38);
			outfile << sslot<<'\n';

			++i;
		}
	}
	outfile.close();
	highscore=FALSE;
}
