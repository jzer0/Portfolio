/*
Header file for the Dog class

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/
#ifndef _DOG_CLASS_H_
#define _DOG_CLASS_H_
#include"Dx11Base.h"
#include"Sprites.h"

class DogClass : public Dx11Base
{

public:

	DogClass( );
	virtual ~DogClass( );
	void setContext(ID3D11DeviceContext* pd3dContext_,ID3D11Buffer* pmvpCB_,XMMATRIX* PvpMatrix_, int catchx, int catchtype, int natmode);
	void setMode(int mode);
	void Update( float dt );
	void Render( );
	void UnloadDog( );
	void hereBoy();

	bool LoadDog(ID3D11Device* d3dDevice_);
	bool showstop();
	bool GotEm();

	int getsound();
	int getmode();

private:

	int DogWalk();
	void DogCatch(int xlocation, int type);

private:

	ID3D11ShaderResourceView* colorMap_[13];
	XMFLOAT2 lastcatchpostion;
	XMMATRIX* ptrvpMatrix_;
	XMFLOAT2 lastpostion;
	ID3D11Buffer* mvpCB_;
	Sprites dogs_[13];

	bool sniffing;
	bool walked;
	bool fetched;
	bool backdown;
	bool played;
	bool showstopper;

	int dogMode;
	int walkcount;
	int dogThrottle;
	int lastDog;
	int sniffcount;
	int barkcount;
	int pickup;
	int pickuptype;
	int laughcount;
	int lastcatchdog;
	int dogsound;
	int nmode;
};

#endif