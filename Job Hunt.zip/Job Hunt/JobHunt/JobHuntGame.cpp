/*
Implementation of JobHuntGame Class

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/

#include "JobHuntGame.h"
#include <ctime>
#include <cmath>

struct VertexPos
{
	XMFLOAT3 pos;
	XMFLOAT2 tex0;
};

JobHuntGame::JobHuntGame( ) : clicked( 0 )
{
	//initialize game object variables

	user_=0;
	clicked= 0;
	delay = 0;
	menuwait=0;
	mode=0;
	mmode=0;
	scoreX2=0;
	scoreY2=0;
	played = 0;
	sdelay = 0;
	wingdelay = 0;
	scoreDisp=FALSE;
	miscount=FALSE;
	quit=FALSE;
	tmode=FALSE;
	hits=0;
	Cplayed=FALSE;
	alreadyset=TRUE;
	fallplayed=FALSE;
	statplay=FALSE;
	sshown=FALSE;
	ckills=FALSE;
	scoredone=FALSE;
	cround=FALSE;
	started=FALSE;
	iplayed=FALSE;
	cmode =0;
	ds=0;
	ls=0;
	lmmode=0;
	font=0;
	kills=0;
	escapes=0;

}

JobHuntGame::~JobHuntGame( )
{

}

// initialize the game object

bool JobHuntGame::LoadGame(HINSTANCE hInstance, HWND hwnd, int screenWidth, int screenHeight,ID3D11Device* Pd3dDevice_, ID3D11DeviceContext* Pd3dContext_ )
{	
	// initialize variables
	srand((unsigned)time(0));
	nature = new Scene;
	d3dDevice_=Pd3dDevice_;
	d3dContext_=Pd3dContext_;

	// create the scene

	bool result = nature->LoadScene(d3dDevice_, d3dContext_);
	if(!nature)
	{
		return false;
	}

	// create the text object

	texter = new TextClass;
	if(!texter)
	{
		return false;
	}
	result = texter->LoadContent(d3dDevice_);
	if(!result)
	{
		MessageBox(hwnd, "Could not initialize the text class object.", "Error", MB_OK);
		return false;
	}

	// create the user input object

	user_ = new Input;
	if(!user_)
	{
		return false;
	}
	result = user_->InputInitialize(hInstance, hwnd, screenWidth, screenHeight, d3dDevice_);
	if(!result)
	{
		MessageBox(hwnd, "Could not initialize the input object.", "Error", MB_OK);
		return false;
	}

	// create the menu object

	menu = new MenuClass;
	if(!menu)
	{
		return false;
	}
	result = menu->Load_Menu(d3dDevice_,texter);
	if(!result)
	{
		MessageBox(hwnd, "Could not initialize the menu object.", "Error", MB_OK);
		return false;
	}

	// create the stats object

	stats = new StatsClass;
	if(!stats)
	{
		return false;
	}
	result = stats->LoadStats(d3dDevice_,texter);
	if(!result)
	{
		MessageBox(hwnd, "Could not initialize the stats object.", "Error", MB_OK);
		return false;
	}

	// create the sound object

	m_Sound = new SoundClass;
	if(!m_Sound)
	{
		return false;
	}
	result = m_Sound->Initialize(hwnd);
	if(!result)
	{
		MessageBox(hwnd, "Could not initialize Direct Sound.", "Error", MB_OK);
		return false;
	}
	return true;
}

//cleanup

void JobHuntGame::UnloadGame( )
{
	if(stats)
	{
		stats->UnloadStats();
		delete stats;
		stats = NULL;
	}
	if(user_)
	{
		user_->Shutdown();
		delete user_;
		user_ = NULL;
	}
	if(texter)
	{
		texter->UnloadContent();
		delete texter;
		texter = NULL;
	}
	if(menu)
	{
		menu->Unload_Menu();
		delete menu;
		menu = NULL;
	}
	if(m_Sound)
	{
		m_Sound->Shutdown();
		delete m_Sound;
		m_Sound=NULL;
	}
	if(nature)
	{
		nature->UnloadScene();
		delete nature;
		nature = NULL;
	}
}

// reset the game object depending on whether the game had run or not

void JobHuntGame::reset()
{
	if(!alreadyset)
	{
		if(nature)
		{
			nature->UnloadScene();
			delete nature;
			nature = NULL;
		}
		if(menu)
		{
			menu->Unload_Menu();
			delete menu;
			menu = NULL;
		}
		if(texter)
		{
			texter->UnloadContent();
			delete texter;
			texter = NULL;

		}
		if(stats)
		{
			stats->UnloadStats();
			delete stats;
			stats = NULL;
		}

		nature = new Scene;
		nature->LoadScene(d3dDevice_, d3dContext_);
		texter = new TextClass;
		texter->LoadContent(d3dDevice_);
		menu = new MenuClass;
		menu->Load_Menu(d3dDevice_,texter);
		stats = new StatsClass;
		stats->LoadStats(d3dDevice_,texter);
		iplayed=FALSE;
	}
	
		clicked= 0;
		delay = 0;
		menuwait=0;
		mode=0;
		mmode=0;
		scoreX2=0;
		scoreY2=0;
		played = 0;
		sdelay = 0;
		wingdelay = 0;
		scoreDisp=FALSE;
		miscount=FALSE;
		quit=FALSE;
		tmode=FALSE;
		hits=0;
		Cplayed=FALSE;
		alreadyset=TRUE;
		fallplayed=FALSE;
		statplay=FALSE;
		sshown=FALSE;
		ckills=FALSE;
		scoredone=FALSE;
		cround=FALSE;
		started=FALSE;
		released=FALSE;
		escapes=0;
		cmode =0;
		ds=0;
		ls=0;
		lmmode=0;
		font=0;
		kills=0;
		escapes=0;
	
}

// update the objects

void JobHuntGame::Update( float dt)
{

	//read input 
	user_->Update(0.0f);
	cmode = menu->getMode();
	smode = stats->getMode();
	started = nature->getStarted();
	released=nature->released();
	escapes=nature->escaped();
	clicked=user_->getSelectedColor();
	if(clicked==1&&(cmode<2||(cmode>4||(cmode==4&&(!nature->showgo()||lmmode==7)))))
	{
		// menu checks for click
		if(cmode==1||cmode>4||(cmode==4&&!nature->showgo()))
		{
			menu->setSelection(clicked);
			cmode = menu->getMode();
		}
		if(cmode>4||(cmode==4&&!nature->showgo()||mmode==7))
		{
			// quit the game

			if(cmode==9)
			{
				quit=TRUE;
				if(cmode==9&&quit==TRUE)
				{
					PostQuitMessage( 0 );
				}
			}

			//start game back up - used for cv mode

			else if(cmode==4&&menu->showmo())
			{
				nature->showOn();
				mmode=4;
			}

			//name clear in high score mode

			else if(cmode==10)
			{
				stats->saveName();
				stats->seths(FALSE);
				user_->clearName();
				menu->setmode(6);
				cmode=6;
			}
			else if(cmode==11)
			{
				user_->clearName();
			}
			else if(cmode==12)
			{
				menu->setmode(0);
				menu->setmode(1);
				cmode=1;
				stats->setMode(0);
				smode=0;
				if(stats->getgover())
				{
					mmode=0;
					cmode=0;
					smode=0;
					reset();

				}
			}
			else if(cmode==15||mmode==15)
			{
				if(mmode==15)
				{
					mmode=15;
				}
				else
				{
					mmode=cmode;
				}
			}
			else if(mmode==7&&cmode!=7)
			{
				mmode = cmode;
				if(mmode<2||((mode==6&&!stats->getHSmode())||(mode==7)))
				{
					reset();
					mmode=0;
				}
			}
			else if(cmode==4&&lmmode==7)
			{
				lmmode==4;
			}
		}
	}

	// stats update

	if(stats->getgover()&&mmode!=7&&cmode!=6)
	{

		mmode=7;
		menu->setmode(1);
		menu->setmode(7);
		cmode=7;
	}

	// check if escaped

	if(user_->escapepress())
	{
		mmode=7;
		lmmode=7;
		cmode=7;
		menu->setmode(7);
	}

	// scene, stat updates when game is running

	if(started&&cmode>1&&cmode<5&&(nature->released())&&clicked==1&&!tmode&&smode==0)
	{	

		if(lmmode!=7&&stats->fired(clicked))
		{
			// check to see if shooting is possible, then proceed with update if so
			nature->setShot(clicked);
			nature->Update(dt);
			ckills= TRUE;
			m_Sound->PlayWaveFile(3);

		}
	}

	// detect miss

	if(started&&escapes>0&&!miscount)
	{
		for(int i = 0; i < escapes;++i)
		{
			stats->missed();
		} 
		miscount=TRUE;
	}

	// detect new target or round

	if(nature->newTarget()||nature->getRound())
	{

		// check if there is a new round, reset aspects as needed
		if(nature->getRound())
		{

			if(smode==0&&!tmode)
			{
				stats->nextround();	
				tmode=TRUE;				
			}
			else if(!stats->checkround())
			{
				nature->reset();
				stats->setMode(0);
				smode=0;
				tmode=FALSE;
				statplay=FALSE;
				played=0;
			}		
		}
		else if(nature->newTarget())
		{
			cround=nature->checkround();
			stats->reload();
			delay=0;
			kills=0;
			scoreDisp=FALSE;
			scoredone=FALSE;
			miscount=FALSE;
			nature->setTarget();
		}
	}

	user_->Frame();
}

void JobHuntGame::Render( )
{
	// draw the game

	if(!quit)
	{
		if(lmmode==7)
		{
			lmmode=cmode;
		}
		smode = stats->getMode();
		curx = user_->getX();
		cury = user_->getY();

		// check if in the main menu mode
		if(cmode < 2)
		{ 
			// render main menu

			if(cmode ==0)
			{
				nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, mode,smode);
				nature->Render();
				if(!iplayed)
				{
				m_Sound->PlayWaveFile(0);
				iplayed=TRUE;
				}

			}
			menu->setContext(d3dContext_, nature->getBuffer(),nature->getMatrix(),curx,cury,0,nature->showgo());
			menu->Render();

			mode = cmode;
			nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, mode,smode);
			nature->Render();

			user_->setContext(d3dContext_,nature->getBuffer(),nature->getMatrix(),0,FALSE);
			user_->Render();
		}

		// check if in a high score mode, entry or display scores

		else if(cmode==6||(smode==6&&cmode!=7))
		{
			stats->setMode(6);
			smode=6;
			menu->isSaved(!stats->getHSmode());


			nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, -1,smode);
			nature->Render();

			if(stats->getHSmode())
			{
				stats->setContext(d3dContext_,nature->getBuffer(),nature->getMatrix(),FALSE,0,6,0,user_->getname());
				stats->Render();
			}
			else
			{
				stats->setContext(d3dContext_,nature->getBuffer(),nature->getMatrix(),FALSE,0,6,0,NULL);
				stats->Render();
			}

			// play high score sound if needed

			if(stats->soundplay()>0&&stats->soundplay()<=10&&!statplay)
			{
				m_Sound->PlayWaveFile(stats->soundplay());
			}
			else if(stats->soundplay()==11&&!statplay)
			{
				m_Sound->PlayWaveFile(stats->soundplay());
				statplay=TRUE;
			}
			else if(stats->soundplay()==12&&statplay)
			{
				m_Sound->PlayWaveFile(stats->soundplay());
				statplay=FALSE;
			}

			// render the high score view

			nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, 6,smode);
			nature->Render();

			menu->setContext(d3dContext_, nature->getBuffer(),nature->getMatrix(),curx,cury,6,nature->showgo());
			menu->Render();

			nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, 6,smode);
			nature->Render();

			user_->setContext(d3dContext_,nature->getBuffer(),nature->getMatrix(),smode,stats->getHSmode());
			user_->Render();

		}

		// check if in escape menu mode

		else if(mmode==7)
		{

			// draw escape menu
			nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, -1,smode);
			nature->Render();
			menu->setContext(d3dContext_, nature->getBuffer(),nature->getMatrix(),curx,cury,7,nature->showgo());
			menu->Render();
			nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, 7,smode);
			nature->Render();
			user_->setContext(d3dContext_,nature->getBuffer(),nature->getMatrix(),0,FALSE);
			user_->Render();
		}

		// check if in game mode

		else if((smode==0&&(mmode<7||mmode==15)&&(cmode>1&&cmode<6)))
		{
			if(mmode==15)
			{
				mmode = cmode;
			}
			if((!stats->checkround())&&(played==0))
			{
				//stop intro sound if needed, run round sound

				m_Sound->StopSound(0);
				m_Sound->PlayWaveFile(1); 
				sdelay = 320;
				played=1;
			}
			else if(!stats->checkround()&&(played==1))
			{
				if (sdelay ==0)
				{
					//play the bark

					m_Sound->PlayWaveFile(2);
					played=2;
				}
				else
				{
					--sdelay;
				}
			}

			// make sure to reset game if over and render the scene 
			if(alreadyset)
			{
				alreadyset=FALSE;
			}

			nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, cmode,smode);
			nature->Render();	
			if(ckills)
			{
				kills=nature->wasShot();
				ckills=FALSE;
			}
			stats->setContext(d3dContext_,nature->getBuffer(),nature->getMatrix(),nature->released(),nature->escaped(),cmode,kills,NULL);
			stats->Render();
			nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, 0, smode);
			nature->Render();

			// check if the dog is supposed to laugh

			ds = nature->getdogsound();
			if(ds >= 5)
			{
				m_Sound->PlayWaveFile(ds);
				ds=0;
			}

			//stall game if in cv mode to display info

			if(cmode==4&&!nature->showgo())
			{
				nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, 0, smode);
				nature->Render();
				menu->setContext(d3dContext_, nature->getBuffer(),nature->getMatrix(),curx,cury,4,nature->showgo());
				menu->Render();
				nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, 0, smode);
				nature->Render();
			}

			// render user target

			user_->setContext(d3dContext_,nature->getBuffer(),nature->getMatrix(),0,FALSE);
			user_->Render();

			// check to see if nature was shot in order to display a score message

			if((kills==1&&!scoreDisp)||(cmode>2&&kills==2&&!scoredone))
			{
				if((kills==1&&!scoreDisp)||(kills==2))
				{
					if(!scoredone)
					{
						stats->scored();

						scoreX = user_->getX()-100;
						scoreY = user_->getY()-300;
						if(scoreY>6400)
						{
							scoreY=5900;
						}
						if(scoreX>8100)
						{
							scoreX=8400;
						}
						if(kills == 2&&!scoreDisp)
						{
							//two with one shot

							score="200";
							stats->scored();
							scoreDisp = TRUE;
							scoredone=TRUE;
							delay=50;
							font=1;
						}
						else
						{
							if(!scoreDisp&&kills==1)
							{
								scoreDisp=TRUE;
								delay=50;
							}
							else if(scoreDisp&&kills>1)
							{
								delay=delay+50;		
								scoredone = TRUE;
							}
							score="100";
							font=0;
						}
					}
				}		
			}
			if(delay>0)
			{
				texter->setContext(d3dContext_, scoreX,scoreY, score,font,25.0,35.5,55.2);
				texter->Render();
				--delay;
			}
			if(cmode < 2)
			{
				nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, 0,smode);
				nature->Render();
			}

			// play flapping sound

			if (nature->released())
			{
				if(wingdelay == 0)
				{
					m_Sound->PlayWaveFile(13);
					m_Sound->PlayWaveFile(4);
					wingdelay = 24;
				}
				else if(wingdelay>0&&wingdelay%12==0)
				{
					
					m_Sound->PlayWaveFile(4);
				}
				
					--wingdelay;
				
			}
			if(nature->getducksound(0)==7||nature->getducksound(1)==7)
			{
				m_Sound->PlayWaveFile(7);

			}
			if(nature->getducksound(0)==8||nature->getducksound(1)==8)
			{
				if(nature->ksound(0)&&nature->ksound(1))
				{
					m_Sound->StopSound(7);
				}
				m_Sound->PlayWaveFile(8);
			}
		}
		else if(smode>0)
		{
			// for tallying the score at the end of the round

			nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, -1,smode);
			nature->Render();
			user_->setContext(d3dContext_,nature->getBuffer(),nature->getMatrix(),0,FALSE);
			user_->Render();
			nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, 0,smode);
			nature->Render();
			stats->setContext(d3dContext_,nature->getBuffer(),nature->getMatrix(),nature->released(),nature->escaped(),cmode,0,NULL);
			stats->Render();
			if(stats->soundplay()>0&&stats->soundplay()<=10&&!statplay)
			{
				m_Sound->PlayWaveFile(stats->soundplay());
			}
			else if(stats->soundplay()==11&&!statplay)
			{
				m_Sound->PlayWaveFile(stats->soundplay());
				statplay=TRUE;
			}
			else if(stats->soundplay()==12&&statplay)
			{
				m_Sound->PlayWaveFile(stats->soundplay());
				statplay=FALSE;
			}
		}
		else if(cmode>14)
		{
			// display credits

			nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, 15,smode);
			nature->Render();
			menu->setContext(d3dContext_, nature->getBuffer(),nature->getMatrix(),curx,cury,15,nature->showgo());
			menu->Render();
			nature->setContext(d3dDevice_,d3dContext_,  backBufferTarget_, curx,cury, 6,0);
			nature->Render();
			user_->setContext(d3dContext_,nature->getBuffer(),nature->getMatrix(),0,FALSE);
			user_->Render();
		}
	}
	// draw the game

	swapChain_->Present( 1, 0 );

}


