/*
Header file for the Scene class

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen

*/

#ifndef _SCENE_H_
#define _SCENE_H_

#include"Dx11Base.h"
#include "Sprites.h"
#include "DuckClass.h"
#include "DogClass.h"
#include <new>

class Scene : public Dx11Base
{

public:

	Scene( );
	virtual ~Scene( );

	ID3D11Buffer* getBuffer();
	XMMATRIX*  getMatrix();

	void setContext(ID3D11Device* Pd3dDevice_,ID3D11DeviceContext* dContext_, ID3D11RenderTargetView* bBufferTarget_, int mouseX, int mouseY, int mode, int tm);
	void*  operator new( size_t size );
	void operator delete( void* p );
	void Update( float dt );
	void setShot(int shot);
	void UnloadScene();
	void setTarget();
	void newround();
	void setRound();
	void showOn();
	void Render();
	void reset();

	bool LoadScene(ID3D11Device* Pd3dDevice_, ID3D11DeviceContext* Pd3dContext_);
	bool ksound(int dnum);
	bool checkround();
	bool getStarted();
	bool newTarget();
	bool getRound();
	bool released();
	bool showgo();	

	int getducksound(int duck);
	int getdogsound();
	int escaped();
	int wasShot();


private:

	ID3D11RenderTargetView* renderTargetView;
	ID3D11ShaderResourceView* colorMap_[11];
	ID3D11SamplerState* colorMapSampler_;
	ID3D11BlendState* alphaBlendState_;
	ID3D11VertexShader* solidColorVS_;
	ID3D11PixelShader* solidColorPS_;
	ID3D11InputLayout* inputLayout_;
	ID3D11Buffer* vertexBuffer_;
	XMMATRIX* PvpMatrix_;
	Sprites sprites_[11];
	ID3D11Buffer* mvpCB_;
	DuckClass* ducks[2];
	XMMATRIX vpMatrix_;
	DogClass* Dog;

	bool started;
	bool newduck;
	bool nround;
	bool drender;
	bool docplay;
	bool shotsfired;
	bool showtime;
	bool showgoon;

	int cvset;
	int pagenum;
	int lastnum;
	int clicked;
	int ddelay;
	int catchsound;
	int duckcount;
	int mX, mY;
	int delay;
	int naturemode;
	int hits;
	int tmode;
	int lastkilled;
	int dshot;

};

#endif