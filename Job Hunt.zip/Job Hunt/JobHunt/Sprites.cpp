/*
  Implementation of the Sprites Class

  Example References:

    Beginning DirectX 11 Game Programming
      By Allen Sherrod and Wendy Jones

	Modified for use in JobHuntGame by Justin Hansen
*/

#include<d3d11.h>
#include<d3dx11.h>
#include"Sprites.h"


Sprites::Sprites( ) : rotation_( 0 )
{
    scale_.x = scale_.y = 1.0f;
}


Sprites::~Sprites( )
{
		
}

XMMATRIX Sprites::GetWorldMatrix( )
{
    XMMATRIX translation = XMMatrixTranslation( position_.x, position_.y, 0.0f );
 	XMMATRIX rotationZ = XMMatrixRotationZ( rotation_ );
    XMMATRIX scale = XMMatrixScaling( scale_.x, scale_.y, 1.0f );

    return rotationZ * translation *  scale;
}

void Sprites::SetPosition( XMFLOAT2& position )
{
    position_ = position;
}

void Sprites::SetRotation( float rotation )
{
    rotation_ = rotation;
}
void Sprites::SetScale( XMFLOAT2& scale )
{
    scale_ = scale;
}
XMFLOAT2 Sprites::getPosition()
{
	return position_;
}