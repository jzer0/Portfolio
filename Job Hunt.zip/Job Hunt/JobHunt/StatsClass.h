/*
Header file for the StatsClass

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/

#ifndef _STATS_CLASS_
#define _STATS_CLASS_

#include"Dx11Base.h"
#include "Sprites.h"
#include "TextClass.h"
#include <sstream>
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

class StatsClass : public Dx11Base
{

public:

	StatsClass( );
	virtual ~StatsClass( );
	void setContext(ID3D11DeviceContext* pd3dContext_,ID3D11Buffer* pmvpCB_,XMMATRIX* PvpMatrix_, bool inflight, int inplay, int gtype, int tleft, char* hsname);
	void setSelection(int selected);
	void Update(float dt);
	void seths(bool set);
	void setMode(int m);
	void UnloadStats();
	void nextround(); 
	void resetdisp();
	void runtally();
	void saveName();
	void addscore();
	void Render();
	void scored();
	void reload();
	void missed();

	bool LoadStats(ID3D11Device* d3dDevice_, TextClass* texter);
	bool ishighscore(int endscore);
	bool fired(int clicked);
	bool displayedscores();
	bool checkTally();
	bool checkround();
	bool getHSmode();
	bool getround();
	bool getgover();

	int getFont(int tX, int tY);
	int soundplay();
	int getMode();

private:

	ID3D11ShaderResourceView* colorMap_[10];
	XMMATRIX* ptrvpMatrix_;
	TextClass* statstext;
	ID3D11Buffer* mvpCB_;
	ofstream scoresfile;
	Sprites info[19];
	string hname;

	char hscores[10][39];
	char * scorptr;
	char  * hsnameptr;
	char* msg;
	char* roundmsg;
	char scoremsg[9];
	char* msnger;
	char* rmsg;
	char rnum[5];
	char scorename[32];
	char sslot[39];
	char newHScore[39];
	char bslot[39];

	bool highscore;
	bool dscores;
	bool reportwin;
	bool newduck;
	bool canshoot;
	bool nround;
	bool upscore;
	bool flymsg;
	bool isinflight;
	bool gover;
	bool flashtally;
	bool tally;

	float msgx;
	float msgy;

	int wasplayed;
	int rkills;
	int hs;
	int namepos;
	int lcarcnt;
	int isinplay;
	int playsound;
	int lcount;
	int gametype;
	int ctargets;
	int tdelay;
	int tflash;
	int misses;
	int roundkills[10][1];
	int bdelay;
	int flasher;
	int wait;
	int mode;
	int font;
	int score;
	int round;
	int ammo;
	int dcount;
	int beatscores[10];
};

#endif