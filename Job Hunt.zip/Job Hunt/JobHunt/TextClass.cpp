/*
Implementation file for TextClass

Example Reference:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

Modified for use in JobHuntGame by Justin Hansen

*/

#include"textclass.h"
#include<xnamath.h>

struct VertexPos
{
	XMFLOAT3 pos;
	XMFLOAT2 tex0;
};

// initialize variables

TextClass::TextClass( ) 
{
	mlocationX=0;
	mlocationY=0;
}

TextClass::~TextClass( )
{

}

// initialize the object

bool TextClass::LoadContent(ID3D11Device* d3dDevice_)
{

	ID3DBlob* vsBuffer = 0;

	// create text sprite

	bool compileResult	= CompileD3DShader( "TextureMap2.fx", "VS_Main", "vs_4_0", &vsBuffer );

	if( compileResult == false )
	{
		DXTRACE_MSG( "Error compiling the vertex shader!" );
		return false;
	}

	HRESULT d3dResult;

	d3dResult = d3dDevice_->CreateVertexShader( vsBuffer->GetBufferPointer( ),
		vsBuffer->GetBufferSize( ), 0, &solidColorVS_ );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Error creating the vertex shader!" );

		if( vsBuffer )
			vsBuffer->Release( );

		return false;
	}

	D3D11_INPUT_ELEMENT_DESC solidColorLayout[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 }
	};

	unsigned int totalLayoutElements = ARRAYSIZE( solidColorLayout );

	d3dResult = d3dDevice_->CreateInputLayout( solidColorLayout, totalLayoutElements,
		vsBuffer->GetBufferPointer( ), vsBuffer->GetBufferSize( ), &inputLayout_ );

	vsBuffer->Release( );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Error creating the input layout!" );
		return false;
	}

	ID3DBlob* psBuffer = 0;

	compileResult = CompileD3DShader( "TextureMap2.fx", "PS_Main", "ps_4_0", &psBuffer );

	if( compileResult == false )
	{
		DXTRACE_MSG( "Error compiling pixel shader!" );
		return false;
	}

	d3dResult = d3dDevice_->CreatePixelShader( psBuffer->GetBufferPointer( ),
		psBuffer->GetBufferSize( ), 0, &solidColorPS_ );

	psBuffer->Release( );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Error creating pixel shader!" );
		return false;
	}

	// load fonts from image files	

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"font4.png", 0, 0, &colorMap_[0], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"font6.png", 0, 0, &colorMap_[1], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	D3D11_SAMPLER_DESC colorMapDesc;
	ZeroMemory( &colorMapDesc, sizeof( colorMapDesc ) );
	colorMapDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	colorMapDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	colorMapDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	colorMapDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
	colorMapDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	colorMapDesc.MaxLOD = D3D11_FLOAT32_MAX;

	d3dResult = d3dDevice_->CreateSamplerState( &colorMapDesc, &colorMapSampler_ );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to create color map sampler state!" );
		return false;
	}

	D3D11_BUFFER_DESC vertexDescA;
	ZeroMemory( &vertexDescA, sizeof( vertexDescA ) );
	vertexDescA.Usage = D3D11_USAGE_DYNAMIC;
	vertexDescA.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	vertexDescA.BindFlags = D3D11_BIND_VERTEX_BUFFER;

	const int sizeOfSprite = sizeof( VertexPos ) * 6;
	const int maxLetters = 37;

	vertexDescA.ByteWidth = sizeOfSprite * maxLetters;

	d3dResult = d3dDevice_->CreateBuffer(&vertexDescA, 0, &vertexBuffer_ );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to create vertex buffer!" );
		return false;
	}

	return true;

}


bool TextClass::DrawString(char* message, float startX, float startY)
{
	// Size in bytes for a single sprite.
	const int sizeOfSprite = sizeof( VertexPos ) * 6;

	// Numbers 0-9, letters A-Z 
	const int maxLetters = 37;

	int length = strlen( message );

	// Clamp for strings too long.
	if( length > maxLetters )
		length = maxLetters;    

	// verts per-triangle (3) * total triangles (2) = 6.
	const int verticesPerLetter = 6;

	D3D11_MAPPED_SUBRESOURCE mapResource;

	HRESULT d3dResult = d3dContext_->Map(vertexBuffer_, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapResource );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to map resource!" );
		return false;
	}

	// Point to our vertex buffer's internal data.
	VertexPos *spritePtr = ( VertexPos* )mapResource.pData;
	const int indexNum0 = static_cast<char>( '0' );
	const int indexNum7 = static_cast<char>( '7' ); //  used for getting to letters
	const int indexA = static_cast<char>( 'A' );
	const int indexZ = static_cast<char>( 'Z' );

	for( int i = 0; i < length; ++i )
	{
		float thisStartX = startX + ( charWidth * static_cast<float>( i ) );
		float thisEndX = thisStartX + charWidth;
		float thisEndY = startY + charHeight;

		spritePtr[0].pos = XMFLOAT3( thisEndX,   thisEndY, 1.0f );
		spritePtr[1].pos = XMFLOAT3( thisEndX,   startY,   1.0f );
		spritePtr[2].pos = XMFLOAT3( thisStartX, startY,   1.0f );
		spritePtr[3].pos = XMFLOAT3( thisStartX, startY,   1.0f );
		spritePtr[4].pos = XMFLOAT3( thisStartX, thisEndY, 1.0f );
		spritePtr[5].pos = XMFLOAT3( thisEndX,   thisEndY, 1.0f );

		int texLookup = 0;
		int letter = static_cast<char>( message[i] );

		if( letter < indexNum0 || letter > indexZ )
		{
			// space
			texLookup = ( indexZ - indexA ) + 11;

		}
		else if  ( letter < indexA )
		{
			// 0 = 0, A = 10, Z = 25, etc.
			texLookup = ( letter - indexNum0 );
		}
		else
		{
			texLookup = ( letter - indexNum7 );
		}

		float tuStart = 0.0f + ( texelWidth * static_cast<float>( texLookup ) );
		float tuEnd = tuStart + texelWidth;
		spritePtr[0].tex0 = XMFLOAT2( tuEnd, 0.0f );
		spritePtr[1].tex0 = XMFLOAT2( tuEnd, 1.0f );
		spritePtr[2].tex0 = XMFLOAT2( tuStart, 1.0f );
		spritePtr[3].tex0 = XMFLOAT2( tuStart, 1.0f );
		spritePtr[4].tex0 = XMFLOAT2( tuStart, 0.0f );
		spritePtr[5].tex0 = XMFLOAT2( tuEnd, 0.0f );
		spritePtr += 6;
	}
	d3dContext_->Unmap( vertexBuffer_, 0 );

	// render text

	d3dContext_->Draw( 6 * length, 0 );

	return true;
}

//cleanup

void TextClass::UnloadContent( )
{
	if( colorMapSampler_ ) colorMapSampler_->Release( );
	if( colorMap_ ) colorMap_[0]->Release( );
	if( colorMap_ ) colorMap_[1]->Release( );
	if( solidColorVS_ ) solidColorVS_->Release( );
	if( solidColorPS_ ) solidColorPS_->Release( );
	if( inputLayout_ ) inputLayout_->Release( );
	if( vertexBuffer_ ) vertexBuffer_->Release( );

	colorMapSampler_ = 0;
	colorMap_[0] = 0;
	colorMap_[1] = 0;
	solidColorVS_ = 0;
	solidColorPS_ = 0;
	inputLayout_ = 0;
	vertexBuffer_ = 0;
}

void TextClass::Update( float dt )
{
	// Nothing to update
}

void TextClass::Render()
{

	if( d3dContext_ == 0 )
		return;


	unsigned int stride = sizeof( VertexPos );
	unsigned int offset = 0;
	d3dContext_->IASetVertexBuffers( 0, 1, &vertexBuffer_, &stride, &offset );
	d3dContext_->IASetPrimitiveTopology( D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST );

	d3dContext_->VSSetShader( solidColorVS_, 0, 0 );
	d3dContext_->PSSetShader( solidColorPS_, 0, 0 );

	d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[fontype] );
	d3dContext_->PSSetSamplers( 0, 1, &colorMapSampler_ );

	// create the text message out of the font at the specified location

	DrawString(textmessage, mlocationX, mlocationY);

}

// set variables for rendering text

void TextClass::setContext(ID3D11DeviceContext* dContext_, float xcord, float ycord, char* msg, int font, float cw, float ch, float tw)
{
	d3dContext_ = dContext_;
	textmessage = msg;
	mlocationX = xcord*.0002-.89;
	fontype= font;
	if (mlocationX >.8)
	{
		mlocationX = mlocationX-.6;

	}
	// Char's width on screen.
	charWidth = cw / 450.0f;

	// Char's height on screen.
	charHeight = ch / 475.0f;

	// Char's texel width.

	texelWidth = tw / 2160.0f;
	mlocationY = ycord*.0003-.95;

}