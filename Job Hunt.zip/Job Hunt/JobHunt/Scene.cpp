/*
Implementation of the Scene class

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/
#include "Scene.h"

#include <ctime>
#include <cmath>
#include <windows.h>
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

struct VertexPos
{
	XMFLOAT3 pos;
	XMFLOAT2 tex0;
};

// initialize scene variables

Scene::Scene() : solidColorVS_( 0 ), solidColorPS_( 0 ),
	inputLayout_( 0 ), vertexBuffer_( 0 ),
	colorMapSampler_( 0 ),
	mvpCB_( 0 ), alphaBlendState_( 0 )
{
	clicked = 0;
	PvpMatrix_ = 0;
	ddelay=1;
	delay=0;
	started = FALSE;
	d3dContext_=0;
	d3dDevice_=0;
	newduck = FALSE;
	duckcount = 1;
	nround=FALSE;
	tmode=0;
	catchsound = 0;
	shotsfired=FALSE;
	lastkilled=0;
	showtime=TRUE;
	showgoon=FALSE;
	drender=FALSE;
	cvset=0;
	pagenum=4;
	lastnum=4;
	docplay=FALSE;
	dshot=0;

	hits=0;
	for (int i = 0; i < 3; ++i)
	{
		colorMap_[i] = 0;
	}

}

Scene::~Scene()
{

}

// used by game to detect if duck sounds should be played

bool Scene::ksound(int dnum)
{
	if(ducks[dnum]->kfall())
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

// used bu game to halt for CV mode

bool Scene::showgo()
{
	return showtime;
}

void Scene::showOn()
{
	showgoon=TRUE;
}

// initialize scene object

bool Scene::LoadScene(ID3D11Device* Pd3dDevice_, ID3D11DeviceContext* Pd3dContext_)
{
	d3dDevice_ = Pd3dDevice_;
	d3dContext_ = Pd3dContext_;
	ShowCursor(false);
	ID3DBlob* vsBuffer = 0;

	// Initialize Graphics elements	  

	bool compileResult = CompileD3DShader( "TextureMap.fx", "VS_Main", "vs_4_0", &vsBuffer );

	if( compileResult == false )
	{
		DXTRACE_MSG( "Error compiling the vertex shader!" );
		return false;
	}

	HRESULT d3dResult;

	d3dResult = d3dDevice_->CreateVertexShader( vsBuffer->GetBufferPointer( ),vsBuffer->GetBufferSize( ), 0, &solidColorVS_ );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Error creating the vertex shader!" );

		if( vsBuffer )
			vsBuffer->Release( );

		return false;
	}

	D3D11_INPUT_ELEMENT_DESC solidColorLayout[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 }
	};

	unsigned int totalLayoutElements = ARRAYSIZE( solidColorLayout );

	d3dResult = d3dDevice_->CreateInputLayout( solidColorLayout, totalLayoutElements,
		vsBuffer->GetBufferPointer( ), vsBuffer->GetBufferSize( ), &inputLayout_ );

	vsBuffer->Release( );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Error creating the input layout!" );
		return false;
	}

	ID3DBlob* psBuffer = 0;

	compileResult = CompileD3DShader( "TextureMap.fx", "PS_Main", "ps_4_0", &psBuffer );

	if( compileResult == false )
	{
		DXTRACE_MSG( "Error compiling pixel shader!" );
		return false;
	}

	d3dResult = d3dDevice_->CreatePixelShader( psBuffer->GetBufferPointer( ),
		psBuffer->GetBufferSize( ), 0, &solidColorPS_ );

	psBuffer->Release( );


	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Error creating pixel shader!" );
		return false;
	}

	//Read in images for sprites

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"background.png", 0, 0, &colorMap_[0], 0 );

	if( FAILED( d3dResult )) 
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"background2.png", 0, 0, &colorMap_[1], 0 );

	if( FAILED( d3dResult )) 
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dh.png", 0, 0, &colorMap_[2], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"credits.png", 0, 0, &colorMap_[3], 0 );

	if( FAILED( d3dResult )) 
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"cv1.png", 0, 0, &colorMap_[4], 0 );

	if( FAILED( d3dResult )) 
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"cv2.png", 0, 0, &colorMap_[5], 0 );

	if( FAILED( d3dResult )) 
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"cv2a.png", 0, 0, &colorMap_[6], 0 );

	if( FAILED( d3dResult )) 
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"cv3.png", 0, 0, &colorMap_[7], 0 );

	if( FAILED( d3dResult )) 
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"cv4.png", 0, 0, &colorMap_[8], 0 );

	if( FAILED( d3dResult )) 
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"cv4a.png", 0, 0, &colorMap_[9], 0 );

	if( FAILED( d3dResult )) 
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"cv5.png", 0, 0, &colorMap_[10], 0 );

	if( FAILED( d3dResult )) 
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	// create duck and dog objects

	ducks[0] = new DuckClass;
	if(!ducks[0])
	{
		return false;
	}
	bool result = ducks[0]->LoadDucks(d3dDevice_);

	ducks[1] = new DuckClass;
	if(!ducks[1])
	{
		return false;
	}
	result = ducks[1]->LoadDucks(d3dDevice_);

	Dog = new DogClass;
	Dog->LoadDog(d3dDevice_);

	// Initialize sprite properties to Window

	ID3D11Resource* colorTex;
	colorMap_[2]->GetResource( &colorTex );

	D3D11_TEXTURE2D_DESC colorTexDesc;
	( ( ID3D11Texture2D* )colorTex )->GetDesc( &colorTexDesc );
	colorTex->Release( );

	float halfWidth = ( float )colorTexDesc.Width / 2.0f;
	float halfHeight = ( float )colorTexDesc.Height / 2.0f;


	VertexPos vertices[] =
	{
		{ XMFLOAT3(  halfWidth,  halfHeight, 1.0f ), XMFLOAT2( 1.0f, 0.0f ) },
		{ XMFLOAT3(  halfWidth, -halfHeight, 1.0f ), XMFLOAT2( 1.0f, 1.0f ) },
		{ XMFLOAT3( -halfWidth, -halfHeight, 1.0f ), XMFLOAT2( 0.0f, 1.0f ) },

		{ XMFLOAT3( -halfWidth, -halfHeight, 1.0f ), XMFLOAT2( 0.0f, 1.0f ) },
		{ XMFLOAT3( -halfWidth,  halfHeight, 1.0f ), XMFLOAT2( 0.0f, 0.0f ) },
		{ XMFLOAT3(  halfWidth,  halfHeight, 1.0f ), XMFLOAT2( 1.0f, 0.0f ) },
	};

	D3D11_BUFFER_DESC vertexDesc;
	ZeroMemory( &vertexDesc, sizeof( vertexDesc ) );
	vertexDesc.Usage = D3D11_USAGE_DEFAULT;
	vertexDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	vertexDesc.ByteWidth = sizeof( VertexPos ) * 6;

	D3D11_SUBRESOURCE_DATA resourceData;
	ZeroMemory( &resourceData, sizeof( resourceData ) );
	resourceData.pSysMem = vertices;

	d3dResult = d3dDevice_->CreateBuffer( &vertexDesc, &resourceData, &vertexBuffer_ );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to create vertex buffer!" );
		return false;
	}

	D3D11_SAMPLER_DESC colorMapDesc;
	ZeroMemory( &colorMapDesc, sizeof( colorMapDesc ) );
	colorMapDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	colorMapDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	colorMapDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	colorMapDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
	colorMapDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	colorMapDesc.MaxLOD = D3D11_FLOAT32_MAX;

	d3dResult = d3dDevice_->CreateSamplerState( &colorMapDesc, &colorMapSampler_ );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to create color map sampler state!" );
		return false;
	}

	D3D11_BUFFER_DESC constDesc;
	ZeroMemory( &constDesc, sizeof( constDesc ) );
	constDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	constDesc.ByteWidth = sizeof( XMMATRIX );
	constDesc.Usage = D3D11_USAGE_DEFAULT;

	d3dResult = d3dDevice_->CreateBuffer( &constDesc, 0, &mvpCB_ );

	if( FAILED( d3dResult ) )
	{
		return false;
	}

	//Sprite scaling and initialize positions

	XMFLOAT2 sprite1scale( 1.25f, 1.25f );
	XMFLOAT2 sprite1Pos( 332.5f, 245.0f );
	sprites_[0].SetPosition( sprite1Pos );
	sprites_[0].SetScale(sprite1scale);

	sprites_[1].SetPosition( sprite1Pos );
	sprites_[1].SetScale(sprite1scale);

	sprites_[2].SetPosition( sprite1Pos );
	sprites_[2].SetScale(sprite1scale);

	XMFLOAT2 sprite3Pos( 320.5f, 245.0f );
	sprites_[3].SetPosition( sprite3Pos );
	sprites_[3].SetScale(sprite1scale);

	XMFLOAT2 sprite4Pos( 325.5f, 225.0f );
	sprites_[4].SetPosition( sprite4Pos );
	sprites_[4].SetScale(sprite1scale);

	sprites_[5].SetPosition( sprite4Pos );
	sprites_[5].SetScale(sprite1scale);

	sprites_[6].SetPosition( sprite4Pos );
	sprites_[6].SetScale(sprite1scale);

	sprites_[7].SetPosition( sprite4Pos );
	sprites_[7].SetScale(sprite1scale);

	sprites_[8].SetPosition( sprite4Pos );
	sprites_[8].SetScale(sprite1scale);

	sprites_[9].SetPosition( sprite4Pos );
	sprites_[9].SetScale(sprite1scale);

	sprites_[10].SetPosition( sprite4Pos );
	sprites_[10].SetScale(sprite1scale);

	//initialize the view

	XMMATRIX view = XMMatrixIdentity( );
	XMMATRIX projection = XMMatrixOrthographicOffCenterLH( 0.0f, 800.0f, 0.0f, 600.0f, 0.1f, 100.0f );
	vpMatrix_ = XMMatrixMultiply( view, projection );
	D3D11_BLEND_DESC blendDesc;
	ZeroMemory( &blendDesc, sizeof( blendDesc ) );
	blendDesc.RenderTarget[0].BlendEnable =TRUE;
	blendDesc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
	blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
	blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
	blendDesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
	blendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
	blendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ONE;
	blendDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
	float blendFactor[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
	d3dDevice_->CreateBlendState( &blendDesc, &alphaBlendState_ );
	d3dContext_->OMSetBlendState( alphaBlendState_, blendFactor, 0xFFFFFFFF );

	return true;
}

void Scene::Render( )
{

	if( d3dContext_ == 0 )
		return;

	float clearColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f };

	// initialize rendering variables
	unsigned int stride = sizeof( VertexPos );
	unsigned int offset = 0;

	// render Background

	d3dContext_->IASetInputLayout( inputLayout_ );
	d3dContext_->IASetVertexBuffers( 0, 1, &vertexBuffer_, &stride, &offset );
	d3dContext_->IASetPrimitiveTopology( D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST );
	d3dContext_->VSSetShader( solidColorVS_, 0, 0 );
	d3dContext_->PSSetShader( solidColorPS_, 0, 0 );
	d3dContext_->PSSetSamplers( 0, 1, &colorMapSampler_ );
	XMMATRIX world = sprites_[0].GetWorldMatrix( );
	XMMATRIX mvp = XMMatrixMultiply( world, vpMatrix_ );
	mvp = XMMatrixTranspose( mvp );
	d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );

	// scene matrix pointer to be passed to objects for rendering

	PvpMatrix_=  &vpMatrix_;

	// check if in a game mode

	if(naturemode > 0&&naturemode<6)
	{
		if(naturemode >=2)
		{
			if(!started)
			{
				// start game

				reset();
				started=TRUE;
				shotsfired=FALSE;
				ddelay=0;
				delay=0;
			}
			d3dContext_->ClearRenderTargetView( backBufferTarget_, clearColor );

			//change backround if a shot is fired

			if(shotsfired)
			{
				d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
				d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[1] );
				d3dContext_->Draw( 6, 0 );
				delay = 2;
				shotsfired=FALSE;
			}
			else
			{
				if(delay > 0)
				{
					d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
					d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[1] );
					d3dContext_->Draw( 6, 0 );
					--delay;
				}
				else
				{
					d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
					d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[0] );
					d3dContext_->Draw( 6, 0 );
				}
			}
		}

		// determine actions of ducks and dog and render as needed

		if(Dog->getmode() >0&&!nround)
		{
			if ((ducks[0]->fetch())||(ducks[1]->fetch())||(ducks[0]->missed())||(ducks[1]->missed()))
			{
				if(naturemode >=3)
				{
					if((ducks[0]->fetch())&&(ducks[1]->fetch())||(ducks[0]->missed())&&(ducks[1]->missed()))
					{
						if((ducks[0]->missed())&&(ducks[1]->missed()))
						{
							Dog->setContext(d3dContext_, mvpCB_, PvpMatrix_, 4000.0,9,naturemode);
						}
						else
						{
							Dog->setContext(d3dContext_, mvpCB_, PvpMatrix_, ducks[lastkilled]->dropzone(),12,naturemode);
						}
						drender=TRUE;
					}
					else if(((ducks[0]->fetch())&&(ducks[1]->missed()))||(ducks[1]->fetch())&&(ducks[0]->missed()))
					{
						if(ducks[0]->fetch())
						{
							Dog->setContext(d3dContext_, mvpCB_, PvpMatrix_, ducks[0]->dropzone(),11,naturemode);
						}
						else
						{
							Dog->setContext(d3dContext_, mvpCB_, PvpMatrix_, ducks[1]->dropzone(),11,naturemode);
						}
						drender=TRUE;
					}
					else if ((!ducks[1]->fetch())&&(!ducks[1]->missed()))
					{
						ducks[1]->setContext(d3dContext_, mvpCB_, PvpMatrix_, clicked, mX, mY);
						ducks[1]->Render();
						if(ducks[0]->fetch())
						{
							lastkilled=1;
						}
					}
					else if (!ducks[0]->fetch()&&(!ducks[0]->missed()))
					{
						ducks[0]->setContext(d3dContext_, mvpCB_, PvpMatrix_, clicked, mX, mY);
						ducks[0]->Render();
						if(ducks[1]->fetch())
						{
							lastkilled=0;
						}
					}
					if(drender)
					{
						Dog->Render();

						// cvmode operations

						if(naturemode==4&&cvset<7)
						{
							if(showtime||!showgoon)
							{
								if(Dog->showstop())
								{
									showgoon=FALSE;
									showtime=FALSE;
								}
							}
							else if(!showtime&&showgoon)
							{
								if(cvset==1||cvset==4)
								{
									++pagenum;
									showgoon=FALSE;
									++cvset;
								}

								// call system to open my CV

								else if(cvset==6&&!docplay)
								{
									system("CV.doc");
									docplay=TRUE;
								}
								else
								{
									++pagenum;
									++cvset;
									showtime=TRUE;
									Dog->hereBoy();
								}
							}
						}
						if(Dog->GotEm()&&showtime)
						{
							duckcount = duckcount+2;
							reset();
							newduck=TRUE;
							drender= FALSE;
						}
					}
				}	

				else
				{
					if(ducks[0]->fetch()&&naturemode==2)
					{
						Dog->setContext(d3dContext_, mvpCB_, PvpMatrix_, ducks[0]->dropzone(),11,naturemode);
					}
					else
					{
						Dog->setContext(d3dContext_, mvpCB_, PvpMatrix_,4000.0,9,naturemode);
					}
					Dog->Render();
					if(Dog->GotEm()&&showtime)
					{
						++duckcount;
						reset();
						newduck=TRUE;
						drender= FALSE;
					}
				}
			}
			else
			{
				ducks[0]->setContext(d3dContext_, mvpCB_, PvpMatrix_, shotsfired, mX, mY);
				ducks[0]->Render();
				if((naturemode >2)&&(ddelay==0))
				{	
					ducks[1]->setContext(d3dContext_, mvpCB_, PvpMatrix_, shotsfired, mX, mY);
					ducks[1]->Render();
				}
				else
				{
					--ddelay;
				}
			}
		}

		// render the grass

		world= sprites_[2].GetWorldMatrix( );
		mvp = XMMatrixMultiply( world, vpMatrix_ );
		mvp = XMMatrixTranspose( mvp );
		d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
		d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
		d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[2]);
		d3dContext_->Draw( 6, 0 );

		// walking dog check

		if(Dog->getmode()==0&&!nround)
		{
			Dog->setContext(d3dContext_,mvpCB_,PvpMatrix_,0,0,naturemode);
			Dog->Render();
		}

		// display cvmode pages

		if(!showtime)
		{
			world= sprites_[pagenum].GetWorldMatrix( );
			mvp = XMMatrixMultiply( world, vpMatrix_ );
			mvp = XMMatrixTranspose( mvp );
			d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
			d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
			d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[pagenum]);
			d3dContext_->Draw( 6, 0 );
		}
	}

	// used for non-game background rendering - main menu, high scores, escape

	else if(naturemode==-1)
	{
		d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
		d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[0] );
		d3dContext_->Draw( 6, 0 );
		world= sprites_[2].GetWorldMatrix( );
		mvp = XMMatrixMultiply( world, vpMatrix_ );
		mvp = XMMatrixTranspose( mvp );
		d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
		d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
		d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[2]);
		d3dContext_->Draw( 6, 0 );
		if(tmode!=6)
		{
			if(Dog->getmode()==0&&!nround)
			{
				Dog->setContext(d3dContext_,mvpCB_,PvpMatrix_,0,0,naturemode);
				Dog->Render();
			}
		}
	}
	else if(naturemode==7)
	{
		world= sprites_[2].GetWorldMatrix( );
		mvp = XMMatrixMultiply( world, vpMatrix_ );
		mvp = XMMatrixTranspose( mvp );
		d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
		d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
		d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[2]);
		d3dContext_->Draw( 6, 0 );
	}
	else if(naturemode==6)
	{
		world= sprites_[2].GetWorldMatrix( );
		mvp = XMMatrixMultiply( world, vpMatrix_ );
		mvp = XMMatrixTranspose( mvp );
		d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
		d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
		d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[2]);
		d3dContext_->Draw( 6, 0 );

	}
	else if(naturemode==15)
	{
		world= sprites_[3].GetWorldMatrix( );
		mvp = XMMatrixMultiply( world, vpMatrix_ );
		mvp = XMMatrixTranspose( mvp );
		d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
		d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
		d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[3]);
		d3dContext_->Draw( 6, 0 );

		world= sprites_[2].GetWorldMatrix( );
		mvp = XMMatrixMultiply( world, vpMatrix_ );
		mvp = XMMatrixTranspose( mvp );
		d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
		d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
		d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[2]);
		d3dContext_->Draw( 6, 0 );
	}

}

// reset the scene

void Scene::reset()
{	
	if(ducks[0])
	{
		ducks[0]->UnloadDucks();
		delete ducks[0];
		ducks[0]= NULL;
	}
	ducks[0] = new DuckClass;
	ducks[0]->LoadDucks(d3dDevice_);
	if(ducks[1])
	{
		ducks[1]->UnloadDucks();
		delete ducks[1];
		ducks[1]= NULL;
	}
	ducks[1] = new DuckClass;
	ducks[1]->LoadDucks(d3dDevice_);
	hits=0;
	dshot=0;
	if(!started||nround)
	{
		if(Dog)
		{
			Dog->UnloadDog();
			delete Dog;
			Dog = NULL;
		}
		Dog = new DogClass;
		Dog->LoadDog(d3dDevice_);
		duckcount=1;
		drender=FALSE;
		nround=FALSE;
	}

}

//cleanup 

void Scene::UnloadScene( )
{
	if( colorMapSampler_ ) colorMapSampler_->Release( );
	if( solidColorVS_ ) solidColorVS_->Release( );
	if( solidColorPS_ ) solidColorPS_->Release( );
	if( inputLayout_ ) inputLayout_->Release( );
	if( vertexBuffer_ ) vertexBuffer_->Release( );
	if( mvpCB_ ) mvpCB_->Release( );
	if( alphaBlendState_ ) alphaBlendState_->Release( );
	for (int i = 0; i < 11; ++i)
	{
		if( colorMap_[i] ) colorMap_[i]->Release( );
		colorMap_[i] = 0;
	}
	if(ducks[0])
	{
		ducks[0]->UnloadDucks();
		delete ducks[0];
		ducks[0]= 0;
	}
	if(ducks[1])
	{
		ducks[1]->UnloadDucks();
		delete ducks[1];
		ducks[1]= 0;
	}
	if(Dog)
	{
		Dog->UnloadDog();
		delete Dog;
		Dog = 0;
	}
	PvpMatrix_=0;
	colorMapSampler_ = 0;
	solidColorVS_ = 0;
	solidColorPS_ = 0;
	inputLayout_ = 0;
	vertexBuffer_ = 0;
	mvpCB_ = 0;
	alphaBlendState_ = 0;
	renderTargetView=0;
}

// update with shots

void Scene::Update( float dt )
{
	if(clicked==1)
	{
		shotsfired=TRUE;
		ducks[0]->setShot();
		ducks[0]->Update(dt);
		ducks[1]->setShot();
		ducks[1]->Update(dt);
	}
}

// set variables for rendering

void Scene::setContext(ID3D11Device* Pd3dDevice_,ID3D11DeviceContext* dContext_, ID3D11RenderTargetView* bBufferTarget_,int mouseX, int mouseY, int mode, int tm)
{
	d3dContext_ = dContext_;
	backBufferTarget_ = bBufferTarget_;
	mX = mouseX;
	mY = mouseY;
	naturemode = mode;
	d3dDevice_ = Pd3dDevice_;
	tmode=tm;
}

// functions to provide variables for rendering other sprites

ID3D11Buffer* Scene::getBuffer()
{
	return mvpCB_;
}
XMMATRIX*  Scene::getMatrix()
{
	return PvpMatrix_;
}

// used to update for shots fired

void Scene::setShot(int shot)
{
	clicked=shot;
}

// lets jgh know how many ducks were killed

int Scene::wasShot()
{


	if(dshot==0)
	{
		hits=0;
		if(ducks[0]->wasShot())
		{
			++hits;
			dshot=1;
		}
		if(naturemode >2)
		{
			if(ducks[1]->wasShot())
			{
				++hits;
				dshot=2;
			}
		}
	}
	else
	{
		if(dshot==2&&ducks[0]->wasShot())
		{
			++hits;
		}
		if(dshot==1&&ducks[1]->wasShot())
		{
			++hits;
		}
	}

	return hits;
}

// user for overloading new

void* Scene::operator new( size_t size )
{
	// _aligned_malloc is a Microsoft specific method (include malloc.h) but its
	// straightforward to implement if you want to be portable by over-allocating
	// and adjusting the address
	void *result = _aligned_malloc( size, 16 );
	if( result )
		return result;

	throw std::bad_alloc(); 
}

void Scene::operator delete( void* p )
{
	if( p ) _aligned_free(p);
}

// tells jhg if there is a new duck

bool Scene::newTarget()
{
	return newduck;
}

void Scene::setTarget()
{
	newduck=FALSE;
}

// check for resetting the round a 10 ducks

bool Scene::checkround()
{
	if(duckcount>10)
	{
		nround=TRUE;
	}
	return nround;
}

// lets jhg know that ducks have been released

bool Scene::released()
{
	if(ducks[0]->released()||(ducks[1]->released()))
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

// tell jhg to play dog catch or laugh sounds

int Scene::getdogsound()
{
	catchsound= Dog->getsound();
	return catchsound;
}

// tell jhg to play duck falling sound

int Scene::getducksound(int duck)
{
	catchsound=ducks[duck]->dsound();

		
		return catchsound;
	
	
}

// tell jhg that duck has escaped

int Scene::escaped()
{
	if(ducks[0]->flewcoop()&&ducks[1]->flewcoop())
	{
		return 2;
	}
	else if(ducks[0]->flewcoop()||ducks[1]->flewcoop())
	{
		return 1;
	}
	else
	{
		return 0;
	}
}



// tells jhg class if a game has started

bool Scene::getStarted()
{
	return started;
}

// tells jhg class if it needs to set up a new round

bool Scene::getRound()
{
	return nround;
}

