/*
Header file for the Dog class

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/
#ifndef _DUCK_CLASS_
#define _DUCK_CLASS_

#include"Dx11Base.h"
#include "Sprites.h"

class DuckClass : public Dx11Base
{

public:

	DuckClass( );
	virtual ~DuckClass( );
	void setContext(ID3D11DeviceContext* dContext_, ID3D11Buffer* PmvpCB_, XMMATRIX* pvpMatrix_, int shot, int mousex, int mousey);
	void Update( float dt );
	void UnloadDucks();
	void nextwave();
	void setShot();
	void Render();

	bool LoadDucks(ID3D11Device* d3dDevice_);
	bool released();
	bool flewcoop();
	bool wasShot();
	bool missed();
	bool fetch();
	bool laugh();
	bool kfall();

	float dropzone();
	int getnextduck();
	int dsound();
	int getX();
	int getY();

private:

	XMFLOAT2 getNextPosition( int oldX, int oldY);
	int getFrame(bool direction);
	int getEscapeFrame();
	int getShotFrame(int current);	

private:

	ID3D11ShaderResourceView* colorMap_[21];
	XMFLOAT2 nextpostion;
	ID3D11Buffer* mvpCB_;
	XMMATRIX* vpMatrix_;
	XMFLOAT2 position_;
	Sprites ducks_[21];

	bool dRight;
	bool dUp;
	bool countSign;
	bool shot;
	bool dogcatch;
	bool doglaugh;
	bool escaped;
	bool fPlayed;
	bool killfall;
	bool inflight;

	float targetx;
	float targety;
	float duckpitch;
	float duckspeed;
	int clicked;
	int wingthrottle;
	int escapeLast;
	int escapeTime;
	int lastPhase;
	int shotback;
	int frameCount;
	int escapeFrame;
	int nextX,nextY;
	int delay;
	int ducksound;
};

#endif