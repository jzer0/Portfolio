/*
Implementation file for the Dog class

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/
#include "DuckClass.h"

#include <ctime>
#include <cmath>

//class initialization

DuckClass::DuckClass()
{
	frameCount = 0;
	lastPhase = 0;
	wingthrottle = 0;
	escapeTime=300;
	countSign = TRUE;
	dogcatch = FALSE;
	doglaugh = FALSE;
	inflight = FALSE;
	killfall = FALSE;
	fPlayed=FALSE;
	escapeFrame = 10;
	escapeLast = 10;
	shot=FALSE;
	vpMatrix_ = 0;
	nextpostion.y = 1;
	dRight = !dRight;  // randomize direction
	nextpostion.x = 1 + (float)rand()/((float)RAND_MAX/(7800.0-1));  //randomize horizontal location
	ducksound=0;
	duckspeed = 40 + (float)rand()/((float)RAND_MAX/(50-40));  //vary speed and pitch
	duckpitch = 30 + (float)rand()/((float)RAND_MAX/(40-30));
	escaped=FALSE;
}

DuckClass::~DuckClass()
{
}

//get x coordinate of duck - used for displaying score text when shot

int DuckClass::getX()
{
	return position_.x;
}

//get x coordinate of duck - same as above

int DuckClass::getY()
{
	return position_.y;
}

// detect when a duck is falling - used for duck fall sound control

bool DuckClass::kfall()
{
	if((fPlayed&&killfall)||(!fPlayed&&!killfall))
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

// Initialize Duck object

bool DuckClass::LoadDucks(ID3D11Device* d3dDevice_)
{
	HRESULT d3dResult;

	// load images

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"d1.png", 0, 0, &colorMap_[0], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"d1L.png", 0, 0, &colorMap_[1], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"d2.png", 0, 0, &colorMap_[2], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"d2L.png", 0, 0, &colorMap_[3], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"d3.png", 0, 0, &colorMap_[4], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"d3L.png", 0, 0, &colorMap_[5], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"d4.png", 0, 0, &colorMap_[6], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"d4L.png", 0, 0, &colorMap_[7], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"d5.png", 0, 0, &colorMap_[8], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"d5L.png", 0, 0, &colorMap_[9], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"daway1.png", 0, 0, &colorMap_[10], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"daway2.png", 0, 0, &colorMap_[11], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"daway3.png", 0, 0, &colorMap_[12], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"daway4.png", 0, 0, &colorMap_[13], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dshot1.png", 0, 0, &colorMap_[14], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dshot2.png", 0, 0, &colorMap_[15], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dshot3.png", 0, 0, &colorMap_[16], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dshot4.png", 0, 0, &colorMap_[17], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dshot5.png", 0, 0, &colorMap_[18], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dshot6.png", 0, 0, &colorMap_[19], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dshot7.png", 0, 0, &colorMap_[20], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	//set scale and initial position

	XMFLOAT2 sprite1scale( .1f, .1f );
	XMFLOAT2 sprite1Pos( 1.0f, 1.0f );
	ducks_[0].SetPosition( sprite1Pos );
	ducks_[0].SetScale(sprite1scale);

	for (int i = 0; i <21; ++i)
	{
		ducks_[i].SetPosition( sprite1Pos );
		ducks_[i].SetScale(sprite1scale);
	}
	return true;
}

// render ducks

void DuckClass::Render()
{
	if( d3dContext_ == 0 )
		return;

	// initialize variables for drawing the duck

	float redColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
	float clearColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
	XMMATRIX vpMatrix;
	vpMatrix.operator=(*vpMatrix_);
	XMMATRIX world = ducks_[0].GetWorldMatrix( );
	XMMATRIX mvp = XMMatrixMultiply( world, vpMatrix );
	mvp = XMMatrixTranspose( mvp );

	// get next duck sprite

	int currentSprite = getnextduck();

	// draw next duck

	position_=nextpostion;
	ducks_[currentSprite].SetPosition(nextpostion);
	world = ducks_[currentSprite].GetWorldMatrix( );
	mvp = XMMatrixMultiply( world, vpMatrix );
	mvp = XMMatrixTranspose( mvp );

	d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
	d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
	d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[currentSprite]);

	d3dContext_->Draw( 6, 0 );

}

// setting the required variables to draw the duck

void DuckClass::setContext(ID3D11DeviceContext* dContext_, ID3D11Buffer* PmvpCB_, XMMATRIX* pvpMatrix_, int shot, int mousex, int mousey)
{
	d3dContext_ = dContext_;
	mvpCB_ = PmvpCB_;
	vpMatrix_ = pvpMatrix_;
	targetx = (float)mousex;
	targety = (float)mousey;
	clicked = shot;
}

//cleanup

void DuckClass::UnloadDucks( )
{
	for (int i = 0; i < 21; ++i)
	{
		if( colorMap_[i] ) colorMap_[i]->Release( );
		colorMap_[i] = 0;
	}
	vpMatrix_ = 0;
	mvpCB_=0;
	if (mvpCB_) mvpCB_->Release();
}

// update used to detect if a duck has been shot

void DuckClass::Update( float dt )
{
	if(clicked == 1)
	{
		if (!shot)
		{
			dRight = !dRight;
			targetx=targetx - (targetx*.185);
			targety=targety - (targety*.185);
			float hitx = abs(targetx - position_.x);
			float hity = abs(targety - position_.y);
			if ((hitx < 150) && (hity < 150))
			{
				shot = TRUE;
				inflight = FALSE;
			}	
			else
			{
				shot = FALSE;
			}
		}
	}
}

//let scene know that a duck was shot

bool DuckClass::wasShot()
{
	return shot;
}

// let scene know that duck has escaped

bool DuckClass::flewcoop()
{
	return escaped;
}

//function to determine the next position of the duck

XMFLOAT2 DuckClass::getNextPosition( int oldX, int oldY)
{
	//check if moving up or down

	if(dUp) 
	{
		if(oldY+duckpitch >= 6150.6) 
		{
			dUp = FALSE;
		}
	}
	if(!dUp) 
	{
		if(oldY-duckpitch < 800 ) 
		{
			dUp = TRUE;
		}
		else 
		{
			dUp = FALSE;
		}
	}

	// check rigtht/left

	if(dRight) 
	{
		if(oldX >= 7900.0) 
		{
			dRight = FALSE;
		}
	}
	if(!dRight) 
	{
		if(oldX < 0 ) 
		{
			dRight = TRUE;
		}
		else 
		{
			dRight = FALSE;
		}
	}
	if (dUp)
	{
		nextY = oldY+duckpitch;
	}
	else
	{
		nextY = oldY-duckpitch;
	}
	if (dRight)
	{
		nextX = oldX+duckspeed;
	}
	else
	{
		nextX = oldX-duckspeed;
	}
	XMFLOAT2 spriteNewpos( nextX, nextY ); 
	return spriteNewpos;
}

// function to draw next duck in flight

int DuckClass::getFrame(bool direction)
{
	if ((frameCount < 8) && (countSign == TRUE))
	{
		frameCount = frameCount + 2;
	}
	else if ((frameCount == 8) && (countSign == TRUE))
	{
		countSign = FALSE;
		frameCount = frameCount - 2;
	}
	else if ((frameCount > 0) && (countSign == FALSE))
	{
		frameCount = frameCount - 2;
	}
	else if (frameCount == 0)
	{
		countSign = TRUE;
	}
	lastPhase = frameCount;
	wingthrottle = 2;
	return frameCount;
}

// function to draw next escaping duck

int DuckClass::getEscapeFrame()
{
	if ((escapeFrame < 13) && (countSign == TRUE))
	{
		++escapeFrame;
	}
	else if ((escapeFrame == 13) && (countSign == TRUE))
	{
		countSign = FALSE;
		--escapeFrame;
	}
	else if ((escapeFrame > 10) && (countSign == FALSE))
	{
		--escapeFrame;
	}
	else if (escapeFrame == 10)
	{
		countSign = TRUE;
	}
	escapeLast = escapeFrame;
	wingthrottle = 2;
	return escapeFrame;
}

// let scene know that duck has been released

bool DuckClass::released()
{
	return inflight;
}

// function to draw next falling duck

int DuckClass::getShotFrame(int current)
{
	if(current < 14)
	{
		lastPhase = 14;
		wingthrottle = 15;
	}
	else if(current==14&&wingthrottle==0)
	{
		lastPhase = ++current;
		wingthrottle = 5;
	}
	if(current > 14 && (current <= 16)&&wingthrottle==0)
	{
		lastPhase = ++current;
		wingthrottle = 2;
	}
	else if ((current >= 16) && (current < 20)&&wingthrottle==0)
	{
		lastPhase = ++current;
		wingthrottle = 2;
	}
	else if (current == 20&&wingthrottle==0)
	{
		lastPhase = 17;
		wingthrottle = 2;
	}
	else
	{
		--wingthrottle;
	}
	return lastPhase;
}

// function to let the scene know to have the dog pick up the duck

bool DuckClass::fetch()
{
	return dogcatch;
}

// function to let scene know that both ducks escaped and to have the dog laugh

bool DuckClass::missed()
{
	return doglaugh;
}

// set up next flying ducks

void DuckClass::nextwave()
{
	dogcatch=FALSE;
	doglaugh = FALSE;
}

// lets scene know where the ducks fell

float DuckClass::dropzone()
{
	return nextpostion.x;
}

// play the fall sound

int DuckClass::dsound()
{
	return ducksound;
}

// function to return the next duck sprite to draw -flying, falling or escaping

int DuckClass::getnextduck()
{
	float oldX;
	float oldY;

	ducksound=0;
	int throttle;
	bool currentDirection;
	inflight = FALSE;

	// Draw duck procedure

	oldX = nextpostion.x;
	oldY = nextpostion.y;
	int csprite = lastPhase;
	throttle = wingthrottle;

	// Check if duck has been shot
	if(dogcatch == FALSE)
	{
		if ((shot) || (csprite >=14))
		{
			// Process shot duck
			inflight = FALSE;
			csprite = getShotFrame(csprite);
			if (csprite < 17)
			{
				nextpostion.x = oldX;
				nextpostion.y = oldY;
				if (csprite == 16&&!fPlayed)
				{
					ducksound=7;
					fPlayed=TRUE;
				}
				else 
				{
					ducksound=0;
				}
			}
			else
			{
				nextpostion.x = oldX;
				nextpostion.y = oldY - 40;
			}
			if (oldY < 2)
			{
				dogcatch=TRUE;
			}
			else if(oldY<400&&oldY>300) 
			{
				killfall=TRUE;
				ducksound=8;
			}
		}

		// If not shot, calculate next position of duck

		else
		{
			inflight = TRUE;
			nextpostion = getNextPosition(oldX,oldY);

			// check if duck should try to fly away

			if ( escapeTime > 0)
			{
				if ( wingthrottle > 0)
				{
					--wingthrottle;
				}
				else
				{
					csprite = getFrame(dRight);
				}
				if (!dRight)
				{
					++csprite;
				}
				--escapeTime;
			}
			else
			{
				if(nextpostion.y < 7000)
				{
					escaped=TRUE;
					csprite = escapeLast;
					nextpostion.y = oldY +40;
					nextpostion.x = oldX;
					if ( wingthrottle > 0)
					{  
						--wingthrottle;
					}
					else 
					{
						csprite = getEscapeFrame();
					}	 
				}
				else
				{
					inflight = FALSE;
					doglaugh = TRUE;
				}
			}
		}
	}
	return csprite;
}

// let duck class know that a shot has been fired

void DuckClass::setShot()
{
	clicked=1;
}
