/*
Header file for the Dog class

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/

#include"DogClass.h"

struct VertexPos
{
	XMFLOAT3 pos;
	XMFLOAT2 tex0;
};

//class initialization

DogClass::DogClass( ) :  mvpCB_( 0 )
{
	lastDog=0;
	sniffing = FALSE;
	sniffcount =0;
	dogMode = 0;
	dogThrottle = 6;
	walkcount = 0;
	walked=FALSE;
	barkcount = 0;
	lastpostion.x= 800.0f;
	lastpostion.y= 400.0f; 
	lastcatchpostion.x= 2000.0f;
	lastcatchpostion.y= 300.0f; 
	ptrvpMatrix_ = 0;
	laughcount = 0;
	backdown=FALSE;
	lastcatchdog=9;
	dogsound=0;
	played=FALSE;
	showstopper=FALSE;
	nmode=0;
}

DogClass::~DogClass( )
{

}

//Dog object initialization

bool DogClass::LoadDog(ID3D11Device* d3dDevice_)
{

	HRESULT d3dResult;

	//load images

	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog1.png", 0, 0, &colorMap_[0], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog1a.png", 0, 0, &colorMap_[1], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog2.png", 0, 0, &colorMap_[2], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog3.png", 0, 0, &colorMap_[3], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog4.png", 0, 0, &colorMap_[4], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog5.png", 0, 0, &colorMap_[5], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog6.png", 0, 0, &colorMap_[6], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog7.png", 0, 0, &colorMap_[7], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog8.png", 0, 0, &colorMap_[8], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog9.png", 0, 0, &colorMap_[9], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog10.png", 0, 0, &colorMap_[10], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog11.png", 0, 0, &colorMap_[11], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}
	d3dResult = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"dog12.png", 0, 0, &colorMap_[12], 0 );

	if( FAILED( d3dResult ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	// set size, initial position of the images

	for(int i =0; i< 13; ++i)
	{
		XMFLOAT2 sprite1Scale(.2f,.2f);
		XMFLOAT2 sprite1Pos( 900.0f,1000.0f );
		dogs_[i].SetPosition( sprite1Pos );
		dogs_[i].SetScale(sprite1Scale);
	}
	return true;
}

// cleanup

void DogClass::UnloadDog( )
{
	for (int i=0; i < 13; ++i)
	{
		if( colorMap_[i] ) colorMap_[i]->Release( );
		colorMap_[i] = 0;
	}
	if( mvpCB_ ) mvpCB_->Release( );
	ptrvpMatrix_=0;
	mvpCB_ = 0;
}

//update not needed,  other functions used

void DogClass::Update( float dt )
{
}

// continue game - used by CV mode to indicate that continue has been clicked

void DogClass::hereBoy()
{
	showstopper=FALSE;
}

// render the dogclass object

void DogClass::Render( )
{
	if( d3dContext_ == 0 )
		return;

	unsigned int stride = sizeof( VertexPos );
	unsigned int offset = 0;

	// determine which dog operation to run

	if (dogMode == 0)
	{
		DogWalk();
	}

	if(pickup >0)
	{
		DogCatch(pickup, pickuptype);
	}

	// draw the dog

	d3dContext_->PSSetShaderResources( 0, 1, &colorMap_[lastDog] );
	XMMATRIX world = dogs_[lastDog].GetWorldMatrix( );
	XMMATRIX vpMatrix_;
	vpMatrix_.operator=(*(ptrvpMatrix_));
	XMMATRIX mvp = XMMatrixMultiply( world, vpMatrix_ );
	mvp = XMMatrixTranspose( mvp );
	d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
	d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );
	d3dContext_->Draw( 6, 0 );
}

// setting the required variables to draw the dog

void DogClass::setContext( ID3D11DeviceContext* pd3dContext_,ID3D11Buffer* pmvpCB_,XMMATRIX* PvpMatrix_, int catchx, int catchtype, int natmode)
{
	d3dContext_ = pd3dContext_;
	mvpCB_ = pmvpCB_;
	ptrvpMatrix_ = PvpMatrix_;
	pickup = catchx;
	pickuptype = catchtype;
	nmode=natmode;
}

// operation to get the dog to walk at beinning of round

int DogClass::DogWalk()
{
	XMFLOAT2 nextpos(lastpostion.x,lastpostion.y);
	if(dogThrottle == 0)
	{
		if(walked == FALSE)
		{
			if(sniffing == TRUE)
			{
				if(sniffcount < 5)
				{
					if(lastDog == 5)
					{
						--lastDog;
						++sniffcount;
					}
					else
					{
						++lastDog;
						++sniffcount;
					}
				}
				else
				{
					sniffcount = 0;
					sniffing = FALSE;
					if(walkcount < 6)
					{
						lastDog = 0;
					}
					else
					{
						++lastDog;
						walked = TRUE;
					}
				}
			}
			else
			{
				nextpos.x = nextpos.x+40;
				if(lastDog ==4)
				{
					++walkcount;
					if((walkcount ==2)||(walkcount==4)||(walkcount==6))
					{
						sniffing = TRUE;
					}
					else
					{
						lastDog = 0;
					}
				}
				else
				{
					++lastDog;
				}
			}
		}
		else 
		{
			if(lastDog <6)
			{
				++lastDog;
			}
			else if((lastDog >= 6) && (lastDog < 8))
			{
				if(barkcount < 2)
				{
					--lastDog;
					++barkcount;
				}
				else
				{
					++lastDog;
					if(lastDog == 7)
					{
						nextpos.y = nextpos.y+260;
					}
				}
			}
			else
			{
				dogMode = 1;
			}
		}
		dogThrottle= 6;
	}
	else
	{
		--dogThrottle;
	}
	lastpostion = nextpos;
	dogs_[lastDog].SetPosition( nextpos );

	return lastDog;
}

// let scene know the current dog sprite

int DogClass::getmode()
{
	return dogMode;
}

// operation to show the dog picking up the duck(s)

void DogClass::DogCatch(int xlocation, int type)
{
	dogsound=0;  // for playing the dog sound
	if (type >= 10)
	{
		lastDog = type;
	}
	else
	{
		lastDog=lastcatchdog;
	}
	lastcatchpostion.x = xlocation/2;
	fetched=FALSE;
	if((dogThrottle == 0)&&(!fetched))
	{
		if((lastcatchpostion.y >= 1)&&(lastcatchpostion.y <620)&&(!backdown))
		{
			lastcatchpostion.y = lastcatchpostion.y+10;
			if((type >=10)&&(played==FALSE)&&(lastcatchpostion.y > 400))
			{
				dogsound=5;
				played=TRUE;
			}
			dogThrottle= 1;
		}
		else if(lastcatchpostion.y >300)
		{
			if((!backdown)&&(laughcount <20))
			{
				if(type < 10)
				{
					if(laughcount==0)
					{
						dogsound=6; 
					}
					if(lastcatchdog==9)
					{
						++lastcatchdog;
					}
					else
					{
						--lastcatchdog;
					}
					lastDog = lastcatchdog;
					dogThrottle = 3;
				}
				else
				{
					dogThrottle = 1;
				}
				++laughcount;
			}
			else if(!showstopper)
			{
				lastcatchpostion.y = lastcatchpostion.y-10;
				backdown=TRUE;
				dogThrottle = 1;
			}
		}
		else
		{
			fetched=TRUE;
			backdown=FALSE;
			pickup = 0;
			laughcount=0;
			played=FALSE;
		}	
	}
	else 
	{
		--dogThrottle;
	}
	dogs_[lastDog].SetPosition( lastcatchpostion);
}

// lets scene know that dog fetch op is complete

bool DogClass::GotEm()
{
	return fetched;
}

// lets jhg class know to play the laugh

int DogClass::getsound()
{
	return dogsound;
}

// used for CV mode to display info between catches

bool DogClass::showstop()
{
	if((lastcatchpostion.y==620&&!showstopper)||showstopper)
	{
		showstopper=TRUE;
		return TRUE;
	}
	else if(lastcatchpostion.y==620&&!showstopper)
	{
		lastcatchpostion.y = lastcatchpostion.y-10;
		backdown=TRUE;
		dogThrottle = 1;
		showstopper=FALSE;
		return FALSE;
	}
	else
	{
		return FALSE;
	}
}