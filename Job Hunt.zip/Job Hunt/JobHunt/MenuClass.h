/*
Header file for the Menu class

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen

*/
#ifndef _MENU_CLASS_
#define _MENU_CLASS_

#include"Dx11Base.h"
#include "Sprites.h"
#include "TextClass.h"

class MenuClass : public Dx11Base
{

public:

	MenuClass( );
	virtual ~MenuClass( );
	void setContext(ID3D11DeviceContext* pd3dContext_,ID3D11Buffer* pmvpCB_,XMMATRIX* PvpMatrix_,float xcord, float ycord,int m, bool pstate);
	void setSelection(int selected);
	void setlastmode(int m);
	void isSaved(bool save);
	void Update( float dt );
	void setmode(int m);
	void Unload_Menu( );
	void Render();

	bool Load_Menu(ID3D11Device* d3dDevice_, TextClass* texter);
	bool showmo();	 

	int getMode();

private:

	int getFont(int tX, int tY);

private:

	ID3D11ShaderResourceView* colorMap_;
	XMMATRIX* ptrvpMatrix_;
	ID3D11Buffer* mvpCB_;
	TextClass* menutext;
	Sprites menuback;

	bool sname;
	bool saved;	
	bool keeplaying;

	float mlocationX;
	float mlocationY;

	int gametype;
	int lasttype;
	int lastmode;
	int wait;
	int mode;
	int font;
};

#endif