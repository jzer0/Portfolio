/*
Implementation of MenuClass

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/

#include"MenuClass.h"
#include<xnamath.h>

struct VertexPos
{
	XMFLOAT3 pos;
	XMFLOAT2 tex0;

};

// initialize variables

MenuClass::MenuClass( ) 
{
	mlocationX=0;
	gametype=0;
	mlocationY=0;
	wait=0;
	mode=0;
	ptrvpMatrix_ = 0;
	font=0;
	saved=FALSE;
	keeplaying=TRUE;
}

MenuClass::~MenuClass( )
{

}

// initialize class

bool MenuClass::Load_Menu(ID3D11Device* d3dDevice_, TextClass* texter)
{

	HRESULT result;

	// point menu text to the scene texter and load the menu background

	menutext = texter;
	result = D3DX11CreateShaderResourceViewFromFile( d3dDevice_,
		"background1.png", 0, 0, &colorMap_, 0 );

	if( FAILED( result ) )
	{
		DXTRACE_MSG( "Failed to load the texture image!" );
		return false;
	}

	// scale and position menu background

	XMFLOAT2 sprite1scale( 1.25f, 1.25f );
	XMFLOAT2 sprite1Pos( 322.5f, 245.0f );
	menuback.SetPosition( sprite1Pos );
	menuback.SetScale(sprite1scale);
	return true;
}

// set required variables to render the menu

void MenuClass::setContext( ID3D11DeviceContext* pd3dContext_,ID3D11Buffer* pmvpCB_,XMMATRIX* PvpMatrix_,float xcord, float ycord,int m, bool pstate)
{
	d3dContext_ = pd3dContext_;
	mvpCB_ = pmvpCB_;
	ptrvpMatrix_ = PvpMatrix_;
	mlocationX=xcord;
	mlocationY=ycord;
	if(mode!=7)
	{
		lasttype=mode;
	}
	mode=m;
	gametype = 0;
	font=0;
	keeplaying=pstate;
}

// didn't use menu update, all done through scene and other functions

void MenuClass::Update( float dt)
{

}

// to continue during CV mode

bool MenuClass::showmo()
{
	return keeplaying;
}

// render menu and text

void MenuClass::Render()
{
	unsigned int stride = sizeof( VertexPos );
	unsigned int offset = 0;
	
	d3dContext_->PSSetShaderResources( 0, 1, &colorMap_ );
	XMMATRIX world = menuback.GetWorldMatrix( );

	XMMATRIX vpMatrix_;
	vpMatrix_.operator=(*(ptrvpMatrix_));

	XMMATRIX mvp = XMMatrixMultiply( world, vpMatrix_ );
	mvp = XMMatrixTranspose( mvp );

	d3dContext_->UpdateSubresource( mvpCB_, 0, 0, &mvp, 0, 0 );
	d3dContext_->VSSetConstantBuffers( 0, 1, &mvpCB_ );

	// determine menu phase and text to display
	
	if(mode==0)
	{
		d3dContext_->Draw( 6, 0 );
		menutext->setContext(d3dContext_,2200,2850, "1 DUCK",getFont(2200,2850),25.0,35.5,55.2);
		menutext->Render();
		menutext->setContext(d3dContext_,4900,2850, "2 DUCKS",getFont(4900,2850),25.0,35.5,55.2);
		menutext->Render();
		menutext->setContext(d3dContext_,2200,2150, "CV MODE",getFont(2200,2150),25.0,35.5,55.2);
		menutext->Render();
		menutext->setContext(d3dContext_,4900,2150, "CREDITS",getFont(4900,2150),25.0,35.5,55.2);
		menutext->Render();
		menutext->setContext(d3dContext_,3100,1450, "HIGH SCORES",getFont(3100,1450),25.0,35.5,55.2);
		menutext->Render();
		mode=1;
	}
	if(mode==4||mode==6||mode==15)
	{
		if(mode==6&&!saved)
		{
			menutext->setContext(d3dContext_,3760,2850, "SAVE",getFont(3760,2850),25.0,35.5,55.2);
			menutext->Render();
			menutext->setContext(d3dContext_,3650,2150, "CLEAR",getFont(3650,2150),25.0,35.5,55.2);
			menutext->Render();
		}
		else if(mode==6||mode==15)
		{
			menutext->setContext(d3dContext_,6450,1350, "MAIN MENU",getFont(6450,1350),20.0,30.5,55.2);
			menutext->Render();
		}
		else
		{
			menutext->setContext(d3dContext_,6600,1350, "CONTINUE",getFont(6450,1350),20.0,30.5,55.2);
			menutext->Render();
		}
	}
	if(mode==7)
	{
		d3dContext_->Draw( 6, 0 );
		menutext->setContext(d3dContext_,3400,2850, "CONTINUE",getFont(3400,2850),25.0,35.5,55.2);
		menutext->Render();
		menutext->setContext(d3dContext_,3300,2150, "QUIT GAME",getFont(3300,2150),25.0,35.5,55.2);
		menutext->Render();
	}
}

// cleanup

void MenuClass::Unload_Menu()
{
	if( colorMap_ ) colorMap_->Release( );
	colorMap_ = 0;
	if( mvpCB_ ) mvpCB_->Release( );
	mvpCB_ = 0;
	menutext=0;
}

// determine if mouseover and change font

int MenuClass::getFont(int tX, int tY)
{
	float hitx=0;;
	float hity=0;
	int xlim=0;;
	if(mode>3&&mode<16)
	{
		if(!saved&&mode<14&&mode>6)
		{
			if(tX==3400||tX==3760)
			{
				if(tX==3400)
				{
					hitx = abs(mlocationX-1700 - tX);

					xlim=1150;
				}
				else
				{
					hitx = abs(mlocationX-1100 - tX);

					xlim=680;
				}
				hity = abs(mlocationY-700 - tY);
			}
			else 
			{
				if(tX==3300)
				{

					hitx = abs(mlocationX-1850 - tX);

					xlim=1400;
				}
				else
				{
					hitx = abs(mlocationX-1250 - tX);

					xlim=780;
				}
				hity = abs(mlocationY-550 - tY);
			}
		}
		else if(mode!=4)
		{
			hitx = abs(mlocationX-1700 - tX);
			hity = abs(mlocationY-550 - tY);
			xlim=1200;
		}
		else
		{
			hitx = abs(mlocationX-1500 - tX);
			hity = abs(mlocationY-550 - tY);
			xlim=950;
		}
	}
	else
	{
		if(tX==2200)
		{
			hitx = abs(mlocationX-1450 - tX);
			hity = abs(mlocationY-600 - tY);
			xlim=900;
		}


		else if(tY != 1450)
		{
			hitx = abs(mlocationX-1550 - tX);
			hity = abs(mlocationY-700 - tY);
			xlim=1050;
		}
		else
		{
			hitx = abs(mlocationX-2100 - tX);
			hity = abs(mlocationY-550 - tY);
			xlim=1600;
		}
	}
	if ((hitx < xlim) && (hity < 200))
	{

		// set type of next phase of the game

		font=1;
		gametype=0;
		switch (tY)
		{
		case 2850:
			if(tX==4900&&mode<2)
			{
				gametype=3;
			}
			else if(tX==2200&&mode<2)
			{
				gametype=2;
			}
			else if(tX==3400)
			{

				gametype=lasttype;
			}
			else if(mode=6)
			{
				gametype=10;
			}
			else
			{
				gametype=mode;
			}
			break;
		case 2150:
			if(tX==2200)
			{
				gametype=4;
			}
			else if(tX==4900&&mode!=7)
			{
				gametype=15;
			}
			else if(tX==3300)
			{
				gametype=9;
			}
			else if(mode==6)
			{
				gametype=11;
			}
			else
			{
				gametype=0;
			}
			break;
		case 1450:
			gametype=6;
			break;
		case 1350:
			if(mode==4)
			{
				
				gametype=4;
			}
			else
			{
				gametype=12;
			}
			break; 
		default:
			gametype = 0;
			break;
		}
	}
	else
	{
		font=0;
	}
	return font;
}

// update the menu class upon clicking an option - used instead of update

void MenuClass::setSelection(int selected)
{
	if (selected !=0&&gametype!=0)
	{
		if(gametype!=7&&mode!=7)
		{
			lasttype=mode;
		}
		if(gametype == 10)
		{
			gametype=10;
			saved=TRUE;
		}
		if(gametype==4)
		{
			keeplaying=TRUE;
		}
		if(gametype==12&&mode==15)
		{
			lasttype=0;
		}
		mode=gametype;
	}
}

// used by the scene to detect menu mode

int MenuClass::getMode()
{
	return mode;
}

// used by scene to update mode

void MenuClass::setmode(int m)
{
	if(mode!=7)
	{
		lasttype=mode;
	}
	mode=m;
}

// used by scene to save previous mode, for escape - continue

void MenuClass::setlastmode(int m)
{
	lastmode=m;
}

// used to check if to save entered high score name

void MenuClass::isSaved(bool save)
{
	saved = save;
}