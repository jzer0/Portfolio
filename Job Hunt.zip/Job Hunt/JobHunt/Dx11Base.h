/*
Header file for the primary DirectX 11 aspects - Dx11Base Class.

Example References:

Beginning DirectX 11 Game Programming
By Allen Sherrod and Wendy Jones

http://www.rastertek.com - various examples

Modified for use in JobHuntGame by Justin Hansen
*/
#ifndef _DX11_BASE_H_
#define _DX11_BASE_H_

#include <d3d11.h>
#include <d3dx11.h>
#include <DxErr.h>
#include <dinput.h>
#include <dxgi.h>
#include <d3dcommon.h>
#include <d3dx10math.h>

class Dx11Base
{

public:

	Dx11Base( );
	virtual ~Dx11Base( );
	virtual bool LoadGame(HINSTANCE hInstance, HWND hwnd, int screenWidth, int screenHeight,ID3D11Device* Pd3dDevice_, ID3D11DeviceContext* Pd3dContext_);
	virtual bool LoadContent();
	virtual void Update( float dt) = 0;
	virtual void UnloadContent( );
	virtual void UnloadGame( );
	virtual void Render( );

	void Shutdown( );

	bool CompileD3DShader( char* filePath, char* entry,char* shaderModel, ID3DBlob** buffer );
	bool Initialize( HINSTANCE hInstance, HWND hwnd );

protected:

	ID3D11RenderTargetView* backBufferTarget_;
	ID3D11DeviceContext* d3dContext_;
	D3D_FEATURE_LEVEL featureLevel_;
	LPDIRECTINPUT8 directInput_;
	D3D_DRIVER_TYPE driverType_;
	IDXGISwapChain* swapChain_;
	ID3D11Device* d3dDevice_;
	HINSTANCE hInstance_;
	HWND hwnd_;
};

#endif