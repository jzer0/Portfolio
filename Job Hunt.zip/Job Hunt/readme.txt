Job Hunt ReadMe

Thank you for trying my game.  In order for this to be installed and run successfully the following prerequisites
must be in place:

DirectX11 Runtime Libraries:

http://www.microsoft.com/en-us/download/confirmation.aspx?id=8109

and

Visual C++ redistributable Libraries

http://www.microsoft.com/en-us/download/details.aspx?id=30679  - choose VSU3\vcredist_x86.exe   


Once these are installed you can run the application from JobHunt.exe in the Release directory. 